package cz.axiom.app

import android.content.Intent
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var store: SecureDeviceStore
    private lateinit var bridge: AxiomBridge
    private val localInference: LocalInferenceEngine = LegacyLlamaCppEngine()
    private lateinit var openDocument: ActivityResultLauncher<Array<String>>
    private lateinit var openDocuments: ActivityResultLauncher<String>
    private var pendingImportCallback: String? = null
    private var pendingDocumentsCallback: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SecureDeviceStore(this)
        openDocuments = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val callback = pendingDocumentsCallback
            pendingDocumentsCallback = null
            if (callback != null) {
                if (uris.isEmpty()) {
                    sendResult(callback, false, "Výběr dokumentů byl zrušen.")
                } else {
                    lifecycleScope.launch(Dispatchers.IO) {
                        val knowledge = LocalKnowledgeStore(this@MainActivity)
                        try {
                            val imported = mutableListOf<Map<String, Any>>()
                            val errors = mutableListOf<String>()
                            uris.take(100).forEach { uri ->
                                runCatching { knowledge.importUri(this@MainActivity, uri) }
                                    .onSuccess { imported += it }
                                    .onFailure { errors += (it.message ?: "Import dokumentu selhal.") }
                            }
                            if (uris.size > 100) errors += "Vybráno více než 100 souborů; další soubory nebyly zpracovány."
                            if (imported.isNotEmpty()) sendResult(callback, true, mapOf("imported" to imported, "errors" to errors))
                            else sendResult(callback, false, errors.joinToString("\n").ifBlank { "Nebylo možné importovat žádný dokument." })
                        } catch (e: Exception) {
                            sendResult(callback, false, e.message ?: "Import znalostí selhal.")
                        } finally {
                            knowledge.close()
                        }
                    }
                }
            }
        }
        openDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val callback = pendingImportCallback
            pendingImportCallback = null
            if (uri == null) {
                callback?.let { sendResult(it, false, "Výběr souboru byl zrušen.") }
            } else if (callback != null) {
                // Large GGUF imports must not run on the UI thread (ANR protection).
                lifecycleScope.launch(Dispatchers.IO) {
                    try {
                        val model = ModelImporter(this@MainActivity, store).copy(uri) { done, total ->
                            reportImportProgress(done, total)
                        }
                        sendResult(callback, true, model)
                        reportModelStatus()
                    } catch (e: Exception) {
                        sendResult(callback, false, e.message ?: "Import modelu selhal.")
                    }
                }
            }
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        bridge = AxiomBridge(this, store)
        webView.addJavascriptInterface(bridge, "AxiomNative")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?) =
                request?.url?.let { assetLoader.shouldInterceptRequest(it) }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request.url
                if (uri.host == "appassets.androidplatform.net") return false
                if (uri.scheme == "https") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    return true
                }
                return true
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/web/index.html")
    }

    fun promptForDeviceToken(callbackId: String, baseUrl: String, onToken: (String) -> Unit) {
        runOnUiThread {
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                hint = "axm_…"
                singleLine = true
            }
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(48, 8, 48, 0)
                addView(input)
            }
            AlertDialog.Builder(this)
                .setTitle("Připojit AXIOM server")
                .setMessage("Vlož device token. Bude uložen šifrovaně v Android Keystore.")
                .setView(container)
                .setNegativeButton("Zrušit") { _, _ -> sendResult(callbackId, false, "Připojení bylo zrušeno.") }
                .setPositiveButton("Ověřit") { _, _ ->
                    val token = input.text.toString().trim()
                    if (token.isBlank()) sendResult(callbackId, false, "Device token nesmí být prázdný.")
                    else onToken(token)
                }
                .show()
        }
    }

    fun launchModelPicker(callbackId: String) {
        runOnUiThread {
            if (pendingImportCallback != null) {
                sendResult(callbackId, false, "Import jiného modelu již probíhá.")
                return@runOnUiThread
            }
            pendingImportCallback = callbackId
            openDocument.launch(arrayOf("*/*"))
        }
    }

    fun launchDocumentsPicker(callbackId: String) {
        runOnUiThread {
            if (pendingDocumentsCallback != null) {
                sendResult(callbackId, false, "Výběr dokumentů již probíhá.")
                return@runOnUiThread
            }
            pendingDocumentsCallback = callbackId
            openDocuments.launch(arrayOf("text/*", "application/markdown", "application/x-markdown"))
        }
    }

    fun sendResult(callbackId: String, success: Boolean, payload: Any?) {
        val json = when (payload) {
            null -> "null"
            is String -> org.json.JSONObject.quote(payload)
            is org.json.JSONObject -> payload.toString()
            is Map<*, *> -> org.json.JSONObject(payload).toString()
            else -> org.json.JSONObject.quote(payload.toString())
        }
        runOnUiThread {
            webView.evaluateJavascript(
                "window.AXIOM_BRIDGE && window.AXIOM_BRIDGE.onResult(${org.json.JSONObject.quote(callbackId)},${success},$json);",
                null
            )
        }
    }

    fun reportImportProgress(done: Long, total: Long?) {
        val totalJson = total?.toString() ?: "null"
        runOnUiThread {
            webView.evaluateJavascript("window.AXIOM_BRIDGE && window.AXIOM_BRIDGE.onModelImportProgress($done,$totalJson);", null)
        }
    }

    fun reportModelStatus() {
        runOnUiThread { webView.evaluateJavascript("window.AXIOM_BRIDGE && window.AXIOM_BRIDGE.refreshModelStatus();", null) }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        runCatching { localInference.cancel() }
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AxiomNative")
            webView.destroy()
        }
        super.onDestroy()
    }
}

class AxiomBridge(private val activity: MainActivity, private val store: SecureDeviceStore) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(330, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .callTimeout(360, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)
        .retryOnConnectionFailure(false)
        .build()

    @JavascriptInterface fun getServerBaseUrl(): String = store.baseUrl()
    @JavascriptInterface fun hasCredentials(): Boolean = store.hasCredentials()
    @JavascriptInterface fun invoke(action: String, payloadJson: String, callbackId: String) {
        if (!callbackId.matches(Regex("[A-Za-z0-9_-]{1,80}"))) return
        val payload = runCatching { org.json.JSONObject(payloadJson.ifBlank { "{}" }) }.getOrElse {
            activity.sendResult(callbackId, false, "Neplatná data požadavku.")
            return
        }
        when (action) {
            "disconnect" -> {
                store.clearConnection()
                activity.sendResult(callbackId, true, org.json.JSONObject().put("disconnected", true))
            }
            "connect" -> {
                val base = runCatching { validateBaseUrl(payload.optString("baseUrl")) }.getOrElse {
                    activity.sendResult(callbackId, false, it.message ?: "Neplatná adresa serveru.")
                    return
                }
                val supplied = payload.optString("token").takeIf { it.isNotBlank() }
                val continueWithToken: (String) -> Unit = { token ->
                    activity.lifecycleScope.launch(Dispatchers.IO) {
                        try {
                            val response = execute(base, token, "/v1/config", "GET", null, null)
                            if (!response.first) throw IllegalStateException(response.second.optString("detail", "Server odmítl připojení."))
                            store.save(base, token)
                            activity.sendResult(callbackId, true, response.second)
                        } catch (e: Exception) {
                            activity.sendResult(callbackId, false, e.message ?: "Připojení selhalo.")
                        }
                    }
                }
                if (supplied == null) activity.promptForDeviceToken(callbackId, base, continueWithToken)
                else continueWithToken(supplied)
            }
            "request" -> activity.lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val base = store.baseUrl()
                    val token = store.token() ?: throw IllegalStateException("Zařízení není připojeno k serveru.")
                    val path = payload.optString("path")
                    val method = payload.optString("method", "GET").uppercase()
                    val body = if (payload.isNull("body")) null else payload.optString("body")
                    val idem = payload.optString("idempotencyKey").takeIf { it.isNotBlank() }
                    val result = execute(base, token, path, method, body, idem)
                    if (result.first) activity.sendResult(callbackId, true, result.second)
                    else activity.sendResult(callbackId, false, result.second.optString("detail", "Server vrátil chybu."))
                } catch (e: Exception) {
                    activity.sendResult(callbackId, false, e.message ?: "Požadavek selhal.")
                }
            }
            "modelStatus" -> activity.sendResult(callbackId, true, org.json.JSONObject(store.modelMetadata()))
            "importModel" -> activity.launchModelPicker(callbackId)
            "importDocuments" -> activity.launchDocumentsPicker(callbackId)
            "listDocuments" -> activity.lifecycleScope.launch(Dispatchers.IO) {
                val knowledge = LocalKnowledgeStore(activity)
                try { activity.sendResult(callbackId, true, mapOf("items" to knowledge.listDocuments())) }
                catch (e: Exception) { activity.sendResult(callbackId, false, e.message ?: "Nelze načíst místní dokumenty.") }
                finally { knowledge.close() }
            }
            "searchDocuments" -> activity.lifecycleScope.launch(Dispatchers.IO) {
                val knowledge = LocalKnowledgeStore(activity)
                try {
                    val query = payload.optString("query").take(4000)
                    activity.sendResult(callbackId, true, mapOf("items" to knowledge.search(query, payload.optInt("limit", 3))))
                } catch (e: Exception) { activity.sendResult(callbackId, false, e.message ?: "Vyhledávání dokumentů selhalo.") }
                finally { knowledge.close() }
            }
            "deleteDocument" -> activity.lifecycleScope.launch(Dispatchers.IO) {
                val knowledge = LocalKnowledgeStore(activity)
                try { activity.sendResult(callbackId, true, mapOf("deleted" to knowledge.deleteDocument(payload.optString("id")))) }
                catch (e: Exception) { activity.sendResult(callbackId, false, e.message ?: "Smazání dokumentu selhalo.") }
                finally { knowledge.close() }
            }
            "localGenerate" -> activity.lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val modelPath = store.modelPath()?.takeIf { java.io.File(it).isFile }
                        ?: throw IllegalStateException("Nejdřív importuj lokální mozek ve formátu GGUF.")
                    val prompt = payload.optString("prompt").trim()
                    require(prompt.isNotEmpty() && prompt.length <= 12000) { "Zadání musí mít 1 až 12 000 znaků." }
                    val bytes = localInference.generate(modelPath, prompt)
                    val text = bytes?.toString(Charsets.UTF_8)?.trim().orEmpty()
                    if (text.isBlank()) throw IllegalStateException("Lokální model nevrátil textový výsledek.")
                    val normalized = runCatching {
                        val obj = org.json.JSONObject(text)
                        obj.optString("text").takeIf { it.isNotBlank() } ?: text
                    }.getOrDefault(text)
                    activity.sendResult(callbackId, true, normalized)
                } catch (e: UnsatisfiedLinkError) {
                    activity.sendResult(callbackId, false, "Nativní runtime AXIOM se nepodařilo načíst: ${e.message}")
                } catch (e: Exception) {
                    activity.sendResult(callbackId, false, e.message ?: "Lokální inference selhala.")
                }
            }
            "cancelLocal" -> {
                runCatching { localInference.cancel() }
                activity.sendResult(callbackId, true, org.json.JSONObject().put("cancelled", true))
            }
            else -> activity.sendResult(callbackId, false, "Neznámá nativní akce.")
        }
    }

    private fun validateBaseUrl(raw: String): String {
        val uri = Uri.parse(raw.trim().trimEnd('/'))
        require(uri.scheme == "https" && !uri.host.isNullOrBlank()) {
            "Server musí používat HTTPS. HTTP není v této verzi povoleno."
        }
        require(uri.userInfo == null && uri.query == null && uri.fragment == null && (uri.path.isNullOrEmpty() || uri.path == "/")) {
            "Zadej pouze základní adresu serveru, bez cesty, přihlašovacích údajů či parametrů."
        }
        return "${uri.scheme}://${uri.host}${if (uri.port != -1) ":${uri.port}" else ""}"
    }

    private fun allowedRoute(path: String, method: String): Boolean {
        if (!path.startsWith("/v1/") || path.contains("..") || path.startsWith("//")) return false
        val parsed = Uri.parse("https://placeholder.invalid$path")
        val route = parsed.path ?: return false
        return when (method) {
            "GET" -> route in setOf("/v1/config", "/v1/capabilities", "/v1/memory", "/v1/runs", "/v1/usage", "/v1/tools")
            "POST" -> route in setOf("/v1/chat", "/v1/memory", "/v1/tools/calculate")
            "DELETE" -> route == "/v1/memory" || route.matches(Regex("/v1/memory/[0-9a-fA-F-]{36}"))
            else -> false
        }
    }

    private fun execute(
        baseUrl: String, token: String, path: String, method: String,
        bodyJson: String?, idempotencyKey: String?
    ): Pair<Boolean, org.json.JSONObject> {
        require(token.startsWith("axm_")) { "Device token není platný." }
        require(allowedRoute(path, method)) { "Tato API cesta není z Android klienta povolena." }
        require(bodyJson == null || bodyJson.toByteArray().size <= 120_000) { "Požadavek je příliš velký." }
        if (idempotencyKey != null) require(idempotencyKey.length <= 128 && idempotencyKey.matches(Regex("[A-Za-z0-9._-]+"))) {
            "Neplatný Idempotency-Key."
        }
        val url = baseUrl.trimEnd('/') + path
        val builder = okhttp3.Request.Builder().url(url).header("Authorization", "Bearer $token").header("Accept", "application/json")
        if (idempotencyKey != null) builder.header("Idempotency-Key", idempotencyKey)
        val requestBody = bodyJson?.toRequestBody("application/json; charset=utf-8".toMediaType())
        when (method) {
            "GET" -> builder.get()
            "POST" -> builder.post(requestBody ?: "{}".toRequestBody("application/json".toMediaType()))
            "DELETE" -> builder.delete(requestBody)
        }
        client.newCall(builder.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val json = runCatching { org.json.JSONObject(text) }.getOrElse { org.json.JSONObject().put("detail", text.take(1000)) }
            return response.isSuccessful to json
        }
    }
}
