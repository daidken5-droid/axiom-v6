package cz.axiom.app

/** Runtime boundary keeps AXIOM orchestration independent from a particular local LLM engine.
 * This beta currently ships only the legacy llama.cpp JNI adapter recovered from AXIOM 2.1.
 * A LiteRT-LM/Gemma implementation can be added without changing chat routing or UI.
 */
internal interface LocalInferenceEngine {
    val engineId: String
    fun generate(modelPath: String, prompt: String): ByteArray?
    fun cancel()
}

internal class LegacyLlamaCppEngine : LocalInferenceEngine {
    override val engineId: String = "llama.cpp-legacy-jni"

    override fun generate(modelPath: String, prompt: String): ByteArray? =
        Offline.generate(modelPath, prompt)

    override fun cancel() {
        Offline.cancel()
    }
}
