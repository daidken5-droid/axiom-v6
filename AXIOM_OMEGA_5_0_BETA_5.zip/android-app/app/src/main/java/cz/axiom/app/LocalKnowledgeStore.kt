package cz.axiom.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID

/** Private, on-device text/Markdown library backed by SQLite FTS4. */
class LocalKnowledgeStore(context: Context) : SQLiteOpenHelper(
    context.applicationContext, "axiom_local_knowledge.db", null, 1
) {
    companion object {
        const val MAX_DOCUMENT_BYTES = 10 * 1024 * 1024
        private const val MAX_DOCUMENTS = 100
        private const val MAX_TOTAL_BYTES = 256L * 1024L * 1024L
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE documents (
                _id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_id TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                content TEXT NOT NULL,
                size_bytes INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                imported_at INTEGER NOT NULL
            )""".trimIndent()
        )
        db.execSQL("CREATE VIRTUAL TABLE documents_fts USING fts4(name, content, tokenize=unicode61 \"remove_diacritics=2\")")
        db.execSQL("CREATE INDEX documents_imported_idx ON documents(imported_at DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // No destructive migrations in beta. Add explicit, versioned migrations before schema changes.
        if (oldVersion != newVersion) throw IllegalStateException("Nepodporovaná migrace místní knihovny.")
    }

    fun importUri(context: Context, uri: Uri): Map<String, Any> {
        val name = displayName(context, uri) ?: "dokument.txt"
        val lower = name.lowercase()
        require(lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".markdown")) {
            "Podporované jsou pouze soubory TXT a Markdown."
        }
        val bytes = readLimited(context, uri)
        require(bytes.isNotEmpty()) { "Dokument je prázdný." }
        val decoder = StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val content = try {
            decoder.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (_: Exception) {
            throw IllegalArgumentException("Dokument není platný UTF-8 text.")
        }
        require(content.isNotBlank()) { "Dokument neobsahuje žádný text." }
        return addDocument(name, content, bytes.size.toLong())
    }

    fun addDocument(name: String, content: String, sizeBytes: Long = content.toByteArray(Charsets.UTF_8).size.toLong()): Map<String, Any> {
        val normalizedName = name.trim().take(240)
        val bytes = content.toByteArray(Charsets.UTF_8)
        require(normalizedName.isNotBlank()) { "Název dokumentu nesmí být prázdný." }
        require(bytes.size in 1..MAX_DOCUMENT_BYTES && sizeBytes in 1..MAX_DOCUMENT_BYTES.toLong()) {
            "Dokument může mít nejvýše 10 MB."
        }
        require(content.isNotBlank()) { "Dokument neobsahuje žádný text." }
        val sha = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val id = UUID.randomUUID().toString()
        val db = writableDatabase
        db.beginTransaction()
        try {
            val count = db.rawQuery("SELECT COUNT(*) FROM documents", null).use { cursor ->
                cursor.moveToFirst(); cursor.getInt(0)
            }
            val total = db.rawQuery("SELECT COALESCE(SUM(size_bytes),0) FROM documents", null).use { cursor ->
                cursor.moveToFirst(); cursor.getLong(0)
            }
            require(count < MAX_DOCUMENTS) { "Místní knihovna může obsahovat nejvýše 100 dokumentů." }
            require(total + bytes.size <= MAX_TOTAL_BYTES) { "Místní knihovna dosáhla limitu 256 MB." }
            val values = ContentValues().apply {
                put("document_id", id); put("name", normalizedName); put("content", content)
                put("size_bytes", bytes.size.toLong()); put("sha256", sha); put("imported_at", System.currentTimeMillis() / 1000)
            }
            val rowId = db.insertOrThrow("documents", null, values)
            val fts = ContentValues().apply { put("rowid", rowId); put("name", normalizedName); put("content", content) }
            db.insertOrThrow("documents_fts", null, fts)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return mapOf("id" to id, "name" to normalizedName, "size" to bytes.size, "sha256" to sha)
    }

    fun listDocuments(): List<Map<String, Any>> {
        val result = mutableListOf<Map<String, Any>>()
        readableDatabase.rawQuery(
            "SELECT document_id,name,size_bytes,sha256,imported_at FROM documents ORDER BY imported_at DESC LIMIT ?",
            arrayOf(MAX_DOCUMENTS.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) result += mapOf(
                "id" to cursor.getString(0), "name" to cursor.getString(1), "size" to cursor.getLong(2),
                "sha256" to cursor.getString(3), "imported_at" to cursor.getLong(4)
            )
        }
        return result
    }

    fun search(query: String, limit: Int = 3): List<Map<String, Any>> {
        val terms = Regex("[\\p{L}\\p{N}]{2,}").findAll(query.lowercase())
            .map { it.value }.distinct().take(12).toList()
        if (terms.isEmpty()) return emptyList()
        val match = terms.joinToString(" OR ") { "\"$it\"" }
        val result = mutableListOf<Map<String, Any>>()
        readableDatabase.rawQuery(
            """SELECT d.document_id,d.name,snippet(documents_fts,'','', ' … '),d.sha256
               FROM documents_fts JOIN documents d ON d._id=documents_fts.rowid
               WHERE documents_fts MATCH ? LIMIT ?""".trimIndent(),
            arrayOf(match, limit.coerceIn(1, 5).toString())
        ).use { cursor ->
            while (cursor.moveToNext()) result += mapOf(
                "id" to cursor.getString(0), "title" to cursor.getString(1),
                "content" to cursor.getString(2).orEmpty().take(4000), "sha256" to cursor.getString(3)
            )
        }
        return result
    }

    fun deleteDocument(documentId: String): Boolean {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val rowId = db.rawQuery("SELECT _id FROM documents WHERE document_id=?", arrayOf(documentId)).use { cursor ->
                if (cursor.moveToFirst()) cursor.getLong(0) else null
            } ?: return false
            db.delete("documents_fts", "rowid=?", arrayOf(rowId.toString()))
            val deleted = db.delete("documents", "_id=?", arrayOf(rowId.toString())) > 0
            db.setTransactionSuccessful()
            return deleted
        } finally {
            db.endTransaction()
        }
    }

    private fun displayName(context: Context, uri: Uri): String? = context.contentResolver.query(
        uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
    )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }

    private fun readLimited(context: Context, uri: Uri): ByteArray {
        val output = ByteArrayOutputStream()
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Systém nemohl otevřít vybraný dokument.")
        input.use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                require(output.size().toLong() + count <= MAX_DOCUMENT_BYTES) { "Dokument překračuje limit 10 MB." }
                output.write(buffer, 0, count)
            }
        }
        return output.toByteArray()
    }
}
