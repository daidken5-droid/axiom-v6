package cz.axiom.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Device token encryption backed by the Android Keystore. The raw token is never returned to JS. */
class SecureDeviceStore(context: Context) {
    private val prefs = context.getSharedPreferences("axiom_secure_v1", Context.MODE_PRIVATE)
    private val alias = "axiom_device_token_aes_gcm_v1"
    private val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun getOrCreateKey(): SecretKey {
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(false)
                .build()
        )
        return generator.generateKey()
    }

    fun save(baseUrl: String, token: String) {
        require(token.startsWith("axm_") && token.length >= 32) { "Neplatný device token." }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + encrypted
        check(prefs.edit().putString("base_url", baseUrl).putString("token_enc", Base64.encodeToString(combined, Base64.NO_WRAP)).commit())
    }

    fun token(): String? {
        val encoded = prefs.getString("token_enc", null) ?: return null
        return try {
            val combined = Base64.decode(encoded, Base64.NO_WRAP)
            require(combined.size > 12)
            val iv = combined.copyOfRange(0, 12)
            val ciphertext = combined.copyOfRange(12, combined.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(ciphertext), Charsets.UTF_8)
        } catch (_: Exception) {
            clearConnection()
            null
        }
    }

    fun baseUrl(): String = prefs.getString("base_url", "") ?: ""
    fun hasCredentials(): Boolean = token() != null && baseUrl().isNotBlank()
    fun modelPath(): String? = prefs.getString("model_path", null)
    fun modelMetadata(): Map<String, Any?> = mapOf(
        "installed" to (modelPath()?.let { java.io.File(it).isFile } == true),
        "name" to prefs.getString("model_name", null),
        "size" to prefs.getLong("model_size", 0L),
        "sha256" to prefs.getString("model_sha256", null)
    )

    fun setModel(path: String, name: String, size: Long, sha256: String) {
        check(prefs.edit().putString("model_path", path).putString("model_name", name)
            .putLong("model_size", size).putString("model_sha256", sha256).commit()) {
            "Metadata modelu se nepodařilo bezpečně uložit."
        }
    }

    fun clearModel() {
        check(prefs.edit().remove("model_path").remove("model_name").remove("model_size").remove("model_sha256").commit())
    }

    fun clearConnection() {
        // Keep the large local model installed when disconnecting the private server.
        check(prefs.edit().remove("base_url").remove("token_enc").commit())
        runCatching { keyStore.deleteEntry(alias) }
    }

    fun clear() {
        prefs.edit().clear().apply()
        runCatching { keyStore.deleteEntry(alias) }
    }
}
