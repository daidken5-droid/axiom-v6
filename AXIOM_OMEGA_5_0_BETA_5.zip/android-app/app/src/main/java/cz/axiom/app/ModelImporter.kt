package cz.axiom.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.os.StatFs
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** Streams a selected GGUF into app-private storage; never buffers the whole model in RAM.
 * Caller must run copy() on Dispatchers.IO. SHA-256 is calculated, not publisher-authenticated.
 */
class ModelImporter(private val context: Context, private val store: SecureDeviceStore) {
    companion object {
        private const val MAX_MODEL_BYTES = 8L * 1024L * 1024L * 1024L
        private const val FREE_SPACE_RESERVE = 384L * 1024L * 1024L
        private const val BUFFER_SIZE = 1024 * 1024
    }

    suspend fun copy(uri: Uri, progress: (Long, Long?) -> Unit): Map<String, Any> {
        val name = displayName(uri) ?: "local-model.gguf"
        require(name.lowercase().endsWith(".gguf")) { "Vybraný soubor nemá příponu .gguf." }
        val reportedSize = reportedSize(uri)
        if (reportedSize != null) {
            require(reportedSize in 24..MAX_MODEL_BYTES) { "Soubor musí mít alespoň 24 B a nejvýše 8 GB." }
        }

        val dir = File(context.filesDir, "models")
        if (dir.exists()) {
            dir.listFiles { file -> file.name.startsWith("axiom-import-") && file.name.endsWith(".part") }
                ?.filter { System.currentTimeMillis() - it.lastModified() > 24L * 60L * 60L * 1000L }
                ?.forEach { runCatching { it.delete() } }
        }
        check(dir.exists() || dir.mkdirs()) { "Nepodařilo se vytvořit interní složku modelů." }
        val free = StatFs(dir.absolutePath).availableBytes
        if (reportedSize != null) {
            require(free - reportedSize >= FREE_SPACE_RESERVE) { "V telefonu není dost volného místa. Uvolni alespoň 384 MB navíc." }
        } else {
            require(free > FREE_SPACE_RESERVE + 1024L * 1024L * 1024L) { "Není dost místa pro bezpečný import velkého modelu." }
        }

        val temp = File.createTempFile("axiom-import-", ".part", dir)
        var written = 0L
        var newFinalFile: File? = null
        val digest = MessageDigest.getInstance("SHA-256")
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Systém nemohl otevřít vybraný soubor.")
            input.use { source ->
                BufferedInputStream(source, BUFFER_SIZE).use { buffered ->
                    FileOutputStream(temp).use { output ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var lastProgress = 0L
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = buffered.read(buffer)
                            if (n < 0) break
                            written += n
                            require(written <= MAX_MODEL_BYTES) { "Model překračuje limit 8 GB." }
                            digest.update(buffer, 0, n)
                            output.write(buffer, 0, n)
                            if (written - lastProgress >= 8L * 1024L * 1024L) {
                                val remaining = StatFs(dir.absolutePath).availableBytes
                                require(remaining >= FREE_SPACE_RESERVE) { "Import byl zastaven: dochází volné místo v telefonu." }
                                progress(written, reportedSize)
                                lastProgress = written
                            }
                        }
                        output.fd.sync()
                    }
                }
            }
            require(written >= 24) { "Soubor je příliš krátký na platnou hlavičku GGUF." }
            validateGgufHeader(temp)
            require(reportedSize == null || written == reportedSize) { "Velikost po importu neodpovídá údajům správce souborů." }

            val sha256 = digest.digest().joinToString("") { "%02x".format(it) }
            val finalFile = File(dir, "model-$sha256.gguf")
            if (finalFile.exists()) {
                require(finalFile.length() == written && sha256Of(finalFile) == sha256) {
                    "V interní složce už existuje soubor se stejným názvem, ale jiným obsahem."
                }
                temp.delete()
            } else {
                check(temp.renameTo(finalFile)) { "Nelze bezpečně dokončit uložení modelu." }
                newFinalFile = finalFile
            }
            val oldPath = store.modelPath()
            store.setModel(finalFile.absolutePath, name, written, sha256)
            if (oldPath != null && oldPath != finalFile.absolutePath) runCatching { File(oldPath).delete() }
            progress(written, reportedSize ?: written)
            return mapOf(
                "installed" to true, "name" to name, "size" to written,
                "sha256" to sha256, "path" to "app-private/models/${finalFile.name}"
            )
        } catch (e: Exception) {
            runCatching { temp.delete() }
            newFinalFile?.let { created ->
                if (store.modelPath() != created.absolutePath) runCatching { created.delete() }
            }
            throw e
        }
    }

    private fun validateGgufHeader(file: File) {
        val header = ByteArray(24)
        DataInputStream(FileInputStream(file)).use { it.readFully(header) }
        require(header.copyOfRange(0, 4).contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) {
            "Soubor nemá platný identifikátor GGUF."
        }
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
        buffer.position(4)
        val version = buffer.int.toLong() and 0xffffffffL
        val tensorCount = buffer.long
        val metadataCount = buffer.long
        require(version in 2L..3L) { "Nepodporovaná verze GGUF: $version (očekává se 2 nebo 3)." }
        require(tensorCount in 1L..1_000_000L) { "Hlavička GGUF obsahuje neplatný počet tensorů." }
        require(metadataCount in 0L..100_000L) { "Hlavička GGUF obsahuje neplatný počet metadat." }
    }

    private suspend fun sha256Of(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(BUFFER_SIZE)
            while (true) {
                currentCoroutineContext().ensureActive()
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun displayName(uri: Uri): String? = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0) else null
    }

    private fun reportedSize(uri: Uri): Long? = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0).takeIf { it > 0 } else null
    }
}
