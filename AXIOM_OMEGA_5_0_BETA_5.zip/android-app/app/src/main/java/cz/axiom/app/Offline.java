package cz.axiom.app;

/** JNI ABI recovered from the user-supplied AXIOM Hybrid 2.1 APK.
 * Native descriptors verified in classes.dex:
 *   public static native void cancel();
 *   public static native byte[] generate(String modelPath, String prompt);
 */
public final class Offline {
    static { System.loadLibrary("axiom"); }
    private Offline() {}
    public static native void cancel();
    public static native byte[] generate(String modelPath, String prompt);
}
