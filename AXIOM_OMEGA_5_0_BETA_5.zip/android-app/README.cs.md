# AXIOM OMEGA Android klient — Beta 5

Android Studio projekt pro ARM64, `minSdk 26`, `targetSdk 35`, `compileSdk 35`.

## Požadavky na build

- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.9.2
- Gradle 8.11.1 (projekt nemá wrapper)

## Hlavní části

- `MainActivity.kt` — WebView, bezpečný JS bridge, HTTPS API klient.
- `SecureDeviceStore.kt` — device token šifrovaný Android Keystore AES-GCM.
- `ModelImporter.kt` — streamovaný import GGUF do app-private storage, SHA-256 a základní kontrola hlavičky.
- `LocalInferenceEngine.kt` — rozhraní runtime; aktuálně `LegacyLlamaCppEngine`.
- `Offline.java` — JNI ABI převzaté z AXIOM Hybrid 2.1.
- `LocalKnowledgeStore.kt` — TXT/Markdown SQLite FTS4 knihovna.
- `app/src/main/assets/web/` — kopie webového klienta shodná se `server/web/`.

## Bezpečnost

- Android ukládá device token mimo JavaScript; token je šifrovaný pomocí Keystore.
- HTTP cleartext je zakázán; server musí používat HTTPS.
- Nativní bridge povoluje pouze předem definované akce a API cesty.
- Velký GGUF import probíhá v IO coroutine, po blocích; kontroluje SHA-256 a základní GGUF hlavičku.

## Upozornění

Plná Android Gradle kompilace a fyzické testy na Pixelu 10a nebyly v tomto pracovním prostředí provedeny. Původní `libaxiom.so` je převzatá z APK 2.1 a musí se otestovat s konkrétním modelem. Samotný výpočet SHA-256 není ověřením důvěryhodnosti modelového vydavatele.

## Automatické vytvoření instalačního APK

V kořeni projektu je `.github/workflows/android-apk.yml`. Po nahrání celého repozitáře do GitHubu spusť v **Actions** workflow **Build AXIOM OMEGA Android APK**. Výsledný debug APK stáhneš z artifactu `AXIOM-OMEGA-5.0-Beta-5-debug-APK`. Podrobný návod je v `BUILD_APK_CZ.md`.
