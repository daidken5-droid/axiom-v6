# Jak získat instalační APK — AXIOM OMEGA 5.0 Beta 5

## Stav

V tomto pracovním prostředí není Android SDK ani Gradle a síťové stahování nástrojů je blokované. APK proto nebylo možné sestavit zde. Projekt nyní obsahuje GitHub Actions workflow, které APK sestaví na GitHub-hosted runneru s Android SDK.

## Nejjednodušší cesta přes GitHub Actions

1. Vytvoř na GitHubu nový **soukromý** repozitář.
2. Rozbal celý projekt AXIOM OMEGA 5.0 Beta 5 a nahraj jeho obsah do kořene repozitáře (včetně skryté složky `.github`). Neposílej do repozitáře žádné `.env`, API klíče, device tokeny, `.jks`, `.keystore`, `.pem` ani soukromé klíče.
3. Otevři v repozitáři kartu **Actions**.
4. Vyber workflow **Build AXIOM OMEGA Android APK** a zvol **Run workflow**.
5. Po úspěšném běhu otevři jeho detail a stáhni artifact **AXIOM-OMEGA-5.0-Beta-5-debug-APK**.
6. Rozbal artifact a nainstaluj `app-debug.apk` do Pixelu 10a. Android může požádat o povolení instalace z prohlížeče/správce souborů.

Workflow používá JDK 17, Android SDK Platform 35, Build Tools 35.0.0 a Gradle 8.11.1. Gradle 8.11.1 odpovídá AGP 8.9.2 v projektu. Debug APK je automaticky podepsané testovacím debug klíčem.

## Důležité k identitě a datům

- Debug build používá aplikační ID `cz.axiom.app.dev`, protože projekt má `applicationIdSuffix = ".dev"`. Může tedy být nainstalován vedle původního AXIOM 2.1; původní instalaci není třeba odinstalovat.
- Debug podpis je určen pro testování. Nejde o stabilní produkční podpis pro aktualizace. Pro dlouhodobé vydávání je nutné vytvořit vlastní release keystore, uložit jej jako chráněné GitHub Actions secrets a přidat release signing konfiguraci.
- Odinstalace debug aplikace odstraní její lokální model, znalostní databázi a nastavení.
- APK obsahuje starší `libaxiom.so` převzatou z původního AXIOM 2.1. Lokální generování proto musí být ověřeno na konkrétním Pixelu 10a a s kompatibilním GGUF modelem.
- Server, OpenAI a Gemini nejsou automaticky nakonfigurovány. Po instalaci je nutné nasadit server a zadat jeho HTTPS adresu a device token.

## Lokální sestavení v Android Studio

Po instalaci Android Studio, JDK 17 a Android SDK Platform 35 otevři složku `android-app/`. Nech Gradle dokončit synchronizaci. Potom zvol **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Výstup bude v:

`android-app/app/build/outputs/apk/debug/app-debug.apk`

Příkazová varianta, pokud je Gradle 8.11.1 v PATH:

```bash
gradle --no-daemon -p android-app clean assembleDebug
```

## Co workflow ověří

- Provedení serverové regresní sady.
- Android kompilaci `assembleDebug`.
- Podpis APK pomocí `apksigner verify`.
- Aplikační ID pomocí `apkanalyzer`.
- SHA-256 výsledného APK.

Úspěšný build není náhradou za fyzický smoke test na Pixelu 10a. Po instalaci otestuj spuštění, připojení HTTPS, import modelu a lokální inference.
