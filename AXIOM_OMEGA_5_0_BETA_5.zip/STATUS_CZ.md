# AXIOM OMEGA 5.0 Beta 5 — stav sestavení a audit

Kontrola: 1. listopadu 2026.

## Souhrn

Beta 5 je rozšířená zdrojová sestava Android klienta a soukromého API serveru. Není to hotové APK ani živě nasazená služba.

## Implementované části

- Android WebView klient s jednotnými webovými assety; zabezpečený most s allowlistem akcí a HTTPS-only síťovým klientem.
- Device bearer token je uložen šifrovaně přes Android Keystore; token se nepředává JavaScriptu v nativním režimu.
- Streamingový GGUF import po 1 MiB blocích mimo UI vlákno, zrušení coroutine, průběh, volné místo, SHA-256 a kontrola 24B hlavičky GGUF (verze 2/3). SHA-256 je kontrola integrity po kopírování, nikoli ověření původu modelu nebo podpisu vydavatele.
- Nativní offline volání je zapouzdřené v rozhraní `LocalInferenceEngine`; aktuální implementace volá JNI `libaxiom.so` převzatou z APK 2.1.
- Místní TXT/Markdown znalostní báze se SQLite FTS4, limitem 100 dokumentů, 10 MB na soubor a 256 MB celkem. Obsah zůstává v privátním sandboxu telefonu, ale tato databáze není samostatně šifrovaná.
- Server: FastAPI, OpenAI Responses API, Gemini Interactions API se `store:false`, web search, konfigurovatelný model routing RANDY.
- Cloud, srovnání poskytovatelů, serverová paměť i odesílání místních úryvků vyžadují explicitní souhlas.
- Jediný aktuálně dostupný serverový nástroj je bezpečná aritmetická kalkulačka; uživatel ji musí výslovně povolit a workflow je limitováno na 2 volání na provider.
- Serverová paměť je AES-GCM šifrovaná s AAD pro device/item; vyhledávací index používá per-device HMAC v2. Index neukládá plaintext, ale odhaluje opakování stejných termínů uvnitř jednoho zařízení. Vyhledávání je lexikální, nikoli sémantické.
- Idempotency cache uchovává odpověď šifrovaně po TTL; po TTL přechází do tombstone stavu. Starší `pending` požadavek se mění na `ambiguous`, nikdy se znovu nedispatchuje. To chrání před dvojím účtováním, ale tombstone metadata zůstávají v DB.
- Provozní běhy ukládají pouze metadata, ne těla promptů a odpovědí.
- Kalkulačka má AST allowlist, rozsahové limity a nemá přístup k souborům, síti ani shellu.
- Docker API kontejner běží non-root, read-only, bez capabilities a s restriktivním umask; Uvicorn access log je vypnutý, privátní API odpovědi mají `no-store` a Caddy zajišťuje TLS a security headers.

## Výsledky kontrol

- Serverová sada: **60/60 testů prošlo**.
- Testy `.env` nově ověřují odmítnutí wildcard hostů a rezervovaného `testserver` i mimo runtime; běžné výchozí hosty jsou pouze `localhost` a `127.0.0.1`.
- `python -m compileall -q app scripts`: prošlo.
- `node --check server/web/app.js`: prošlo.
- Android XML soubory: parsování prošlo.
- Serverové PWA a Android WebView assety: všechny zrcadlené soubory jsou byte-for-byte shodné.
- Kotlin `LocalInferenceEngine` rozhraní bylo samostatně přeloženo přes `javac` + `kotlinc`; `ModelImporter` a `MainActivity` nebyly zkompilovány proti Android SDK. Plná Gradle Android sestava nebyla v tomto prostředí provedena.
- ZIP archiv je před vydáním zkontrolován bez databází, `.env`, klíčů a build artefaktů.
- Globální `pip check` hlásí existující konflikt balíčku `moviepy` s `Pillow` v předinstalovaném pracovním prostředí; `moviepy` není závislostí AXIOMu. Přímé verze AXIOM serveru odpovídají připnutým požadavkům.

## Omezení a neověřené body

1. **APK nebylo sestaveno ani podepsáno.** V pracovním prostředí není Android SDK ani Gradle wrapper/toolchain.
2. **Pixel 10a nebyl fyzicky otestován.** Výkon, RAM, teplota, import a lokální generování nejsou změřené.
3. Původní `libaxiom.so` pochází z uživatelského APK 2.1; její C/C++ zdroje a přesná vazba na podporované GGUF modely nebyly dodány.
4. Gemma 4 E2B a LiteRT-LM jsou doporučený další lokální runtime, ale nejsou součástí tohoto běhu. Rozhraní `LocalInferenceEngine` umožňuje přidat nový adaptér bez změny orchestrace.
5. OpenAI/Gemini nebyly volány se skutečnými klíči; žádné náklady nebyly v testech vytvořeny.
6. VPS, DNS a TLS nebyly nasazeny ani ověřeny.
7. RANDY je deterministická heuristika, nikoli model natrénovaný na evaluační sadě.
8. HADES kontroluje strukturu odpovědi a bezpečné URL; neověřuje pravdivost faktů ani důvěryhodnost citovaných domén.
9. Agentní módy `answer`, `research`, `writer`, `audit` jsou instrukční profily jednoho omezeného volání; nejde o obecný autonomní agentní orchestrátor.
10. Nejsou implementovány streamované tokeny, upload obrázků, vektorové/sémantické vyhledávání ani Gemma runtime.
11. Rate limiter je in-memory a podporuje jediný serverový proces. Pro více replik je potřeba Redis/distribuovaný limiter.
12. PWA ve webovém prohlížeči uchovává device token v `sessionStorage`; nativní Android používá Keystore. Produkční použití doporučuje nativní klient.

## Nasazení serveru

VPS musí mít Ubuntu 24.04 LTS nebo Debian 12, doménu a otevřené porty 80/443. Server nespouští lokální LLM; slouží jako autentizační, bezpečnostní, paměťová a provider orchestrace vrstva. Viz `server/docs/DEPLOY_CZ.md`.

## Android build

Otevřít `android-app/` v Android Studio s JDK 17, Android SDK Platform 35, AGP 8.9.2 a Gradle 8.11.1. Projekt nemá Gradle wrapper. Před instalací release APK je nutné nastavit podpis. Odinstalace původní APK maže její privátní data.

## Dodatek Beta 5 — instalační APK

Beta 5 přidává `.github/workflows/android-apk.yml` a `android-app/BUILD_APK_CZ.md`. Workflow sestaví a ověří debug APK na GitHub Actions. V tomto místním prostředí zůstává APK nesestaveno, protože zde není Gradle ani Android SDK a síťové stahování nástrojů selhává. Po spuštění workflow se artefakt stáhne z detailu běhu GitHub Actions. Debug varianta má aplikační ID `cz.axiom.app.dev` a může být nainstalována vedle původní aplikace.
