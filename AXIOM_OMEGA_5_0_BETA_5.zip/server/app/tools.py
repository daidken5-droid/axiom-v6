from __future__ import annotations

import ast
import operator


_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY = {ast.UAdd: operator.pos, ast.USub: operator.neg}


def safe_calculate(expression: str) -> int | float:
    """Evaluate arithmetic only. No names, calls, attributes, indexing, or imports."""
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as exc:
        raise ValueError("Invalid arithmetic expression") from exc

    nodes = list(ast.walk(tree))
    if len(nodes) > 64:
        raise ValueError("Expression is too complex")

    def visit(node):
        if isinstance(node, ast.Expression):
            return visit(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            if not (float("-inf") < float(node.value) < float("inf")) or abs(node.value) > 1e15:
                raise ValueError("Numeric literal is outside the safe range")
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in _BINOPS:
            left, right = visit(node.left), visit(node.right)
            if isinstance(node.op, ast.Pow) and (abs(right) > 8 or abs(left) > 1e6):
                raise ValueError("Exponent is outside the safe range")
            value = _BINOPS[type(node.op)](left, right)
            if isinstance(value, complex) or abs(value) > 1e15:
                raise ValueError("Result is outside the safe range")
            return value
        if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY:
            return _UNARY[type(node.op)](visit(node.operand))
        raise ValueError("Only basic arithmetic is allowed")

    try:
        result = visit(tree)
    except (ZeroDivisionError, OverflowError) as exc:
        raise ValueError("Arithmetic operation is not valid") from exc
    if not isinstance(result, (int, float)):
        raise ValueError("Result is not finite")
    try:
        finite = float("-inf") < float(result) < float("inf")
    except OverflowError as exc:
        raise ValueError("Result is outside the safe range") from exc
    if not finite or abs(result) > 1e15:
        raise ValueError("Result is outside the safe range")
    return result
