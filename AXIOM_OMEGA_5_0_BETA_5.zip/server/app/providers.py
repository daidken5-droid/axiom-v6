from __future__ import annotations

import json
import time
from typing import Any
from urllib.parse import urlsplit

import httpx

from .tools import safe_calculate


class ProviderError(Exception):
    def __init__(self, provider: str, status_code: int | None, message: str):
        super().__init__(message)
        self.provider = provider
        self.status_code = status_code
        self.safe_message = message


CALCULATOR_TOOL_NAME = "axiom_calculator"
CALCULATOR_DESCRIPTION = (
    "Evaluate a short arithmetic expression using AXIOM's isolated, local, arithmetic-only calculator. "
    "Use only for arithmetic; it cannot access files, the network, shell commands, or user accounts."
)
CALCULATOR_PARAMETERS = {
    "type": "object",
    "properties": {
        "expression": {
            "type": "string",
            "description": "A basic arithmetic expression, maximum 160 characters.",
        }
    },
    "required": ["expression"],
    "additionalProperties": False,
}
MAX_CALCULATOR_CALLS = 2


def _calculator_result(arguments: Any) -> dict[str, Any]:
    """Execute the only currently exposed side-effect-free tool."""
    if not isinstance(arguments, dict) or set(arguments) != {"expression"}:
        return {"error": "Invalid calculator arguments"}
    expression = arguments.get("expression")
    if not isinstance(expression, str) or not expression.strip() or len(expression) > 160:
        return {"error": "Expression must be a non-empty string of at most 160 characters"}
    try:
        return {"result": safe_calculate(expression)}
    except ValueError as exc:
        return {"error": str(exc)}


def _history_as_text(history: list[dict[str, str]], prompt: str) -> str:
    rows = []
    for item in history[-12:]:
        role = "AXIOM_USER" if item["role"] == "user" else "AXIOM_ASSISTANT"
        rows.append(f"{role}: {item['content']}")
    rows.append(f"AXIOM_USER: {prompt}")
    return "\n\n".join(rows)


def _openai_tools(web_search: bool, calculator: bool) -> list[dict[str, Any]]:
    tools: list[dict[str, Any]] = []
    if web_search:
        tools.append({"type": "web_search"})
    if calculator:
        tools.append({
            "type": "function",
            "name": CALCULATOR_TOOL_NAME,
            "description": CALCULATOR_DESCRIPTION,
            "parameters": CALCULATOR_PARAMETERS,
            "strict": True,
        })
    return tools


def _extract_openai(data: dict[str, Any]) -> tuple[str, list[dict[str, str]], list[dict[str, Any]]]:
    text = data.get("output_text")
    if not isinstance(text, str) or not text:
        chunks: list[str] = []
        for item in data.get("output", []) or []:
            if not isinstance(item, dict) or item.get("type") != "message":
                continue
            for content in item.get("content", []) or []:
                if isinstance(content, dict) and content.get("type") in {"output_text", "text"} and isinstance(content.get("text"), str):
                    chunks.append(content["text"])
        text = "\n".join(chunks)

    sources: list[dict[str, str]] = []
    for item in data.get("output", []) or []:
        if not isinstance(item, dict) or item.get("type") != "web_search_call":
            continue
        action = item.get("action") if isinstance(item.get("action"), dict) else {}
        for src in action.get("sources", []) or []:
            if not isinstance(src, dict):
                continue
            url = src.get("url")
            if _is_http_url(url):
                sources.append({"title": str(src.get("title") or url)[:300], "url": url})
    return text or "", sources, data.get("output", []) or []


def _sum_usage(total: dict[str, int], usage: Any, input_key: str, output_key: str) -> None:
    if not isinstance(usage, dict):
        return
    for target, key in (("input_tokens", input_key), ("output_tokens", output_key)):
        value = usage.get(key)
        if isinstance(value, int) and value >= 0:
            total[target] += value


async def call_openai(
    *, api_key: str, model: str, system_prompt: str, prompt: str,
    history: list[dict[str, str]], web_search: bool, max_output_tokens: int,
    reasoning_effort: str, timeout: float, enable_calculator: bool = False,
) -> dict[str, Any]:
    initial_input = _history_as_text(history, prompt)
    conversation_items: list[dict[str, Any]] = [{"role": "user", "content": initial_input}]
    all_sources: list[dict[str, str]] = []
    seen_sources: set[str] = set()
    usage_total = {"input_tokens": 0, "output_tokens": 0}
    used_tools: list[dict[str, Any]] = []
    final_text = ""
    final_id = None
    total_tool_calls = 0
    deadline = time.monotonic() + timeout

    # Up to two pure/local calculator calls, then one final model turn with no callable tools.
    for tool_round in range(MAX_CALCULATOR_CALLS + 1):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ProviderError("openai", None, "OpenAI tool workflow exceeded its total time budget")
        tools = _openai_tools(web_search, enable_calculator and tool_round < MAX_CALCULATOR_CALLS)
        payload: dict[str, Any] = {
            "model": model,
            "instructions": system_prompt,
            "input": initial_input if tool_round == 0 else conversation_items,
            "max_output_tokens": max_output_tokens,
            "store": False,
            "reasoning": {"effort": reasoning_effort},
            "include": ["web_search_call.action.sources"] if web_search else [],
        }
        if tools:
            payload["tools"] = tools
        if enable_calculator and tool_round < MAX_CALCULATOR_CALLS:
            payload["parallel_tool_calls"] = False

        try:
            async with httpx.AsyncClient(timeout=remaining) as client:
                response = await client.post(
                    "https://api.openai.com/v1/responses",
                    headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                    json=payload,
                )
        except httpx.TimeoutException as exc:
            raise ProviderError("openai", None, "OpenAI request timed out; no blind retry was attempted") from exc
        except httpx.HTTPError as exc:
            raise ProviderError("openai", None, "Could not connect to OpenAI") from exc

        if response.is_error:
            raise ProviderError("openai", response.status_code, f"OpenAI returned HTTP {response.status_code}")
        try:
            data = response.json()
        except ValueError as exc:
            raise ProviderError("openai", response.status_code, "OpenAI returned an unreadable response") from exc
        if not isinstance(data, dict):
            raise ProviderError("openai", response.status_code, "OpenAI returned an unexpected response")

        final_text, sources, output_items = _extract_openai(data)
        final_id = data.get("id") or final_id
        _sum_usage(usage_total, data.get("usage"), "input_tokens", "output_tokens")
        for source in sources:
            if source["url"] not in seen_sources:
                seen_sources.add(source["url"])
                all_sources.append(source)

        calls = [item for item in output_items if isinstance(item, dict) and item.get("type") == "function_call"]
        if not calls:
            break
        if not enable_calculator or tool_round >= MAX_CALCULATOR_CALLS:
            raise ProviderError("openai", None, "OpenAI requested a tool that AXIOM did not authorize")

        # Preserve all output items (including reasoning items required by some models) exactly.
        conversation_items.extend(output_items)
        for call in calls:
            total_tool_calls += 1
            call_id = call.get("call_id")
            name = call.get("name")
            if total_tool_calls > MAX_CALCULATOR_CALLS or name != CALCULATOR_TOOL_NAME or not isinstance(call_id, str):
                result = {"error": "Tool call is not available or the per-request limit was reached"}
            else:
                try:
                    arguments = json.loads(call.get("arguments", "{}"))
                except (TypeError, json.JSONDecodeError):
                    arguments = None
                result = _calculator_result(arguments)
            used_tools.append({"name": str(name or "unknown"), "ok": "error" not in result})
            conversation_items.append({
                "type": "function_call_output",
                "call_id": call_id if isinstance(call_id, str) else "invalid-call-id",
                "output": json.dumps(result, ensure_ascii=False, separators=(",", ":")),
            })
    else:  # pragma: no cover - loop is bounded by the range above
        raise ProviderError("openai", None, "AXIOM tool loop exceeded its safety bound")

    return {
        "text": final_text,
        "sources": all_sources,
        "usage": usage_total,
        "provider_response_id": final_id,
        "tools_used": used_tools,
    }


def _is_http_url(value: Any) -> bool:
    if not isinstance(value, str) or len(value) > 2048:
        return False
    try:
        parsed = urlsplit(value)
        return parsed.scheme == "https" and bool(parsed.hostname) and parsed.username is None and parsed.password is None
    except ValueError:
        return False


def parse_gemini_interaction(data: dict[str, Any]) -> dict[str, Any]:
    """Normalize the Gemini Interactions API response to AXIOM's provider shape."""
    text_chunks: list[str] = []
    sources: list[dict[str, str]] = []
    seen_urls: set[str] = set()
    steps = data.get("steps", []) or []

    for step in steps:
        if not isinstance(step, dict) or step.get("type") != "model_output":
            continue
        for block in step.get("content", []) or []:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "text" and isinstance(block.get("text"), str):
                text_chunks.append(block["text"])
            for annotation in block.get("annotations", []) or []:
                if not isinstance(annotation, dict) or annotation.get("type") != "url_citation":
                    continue
                url = annotation.get("url")
                if _is_http_url(url) and url not in seen_urls:
                    seen_urls.add(url)
                    sources.append({"title": str(annotation.get("title") or url)[:300], "url": url})

    if not text_chunks and isinstance(data.get("output_text"), str):
        text_chunks.append(data["output_text"])
    usage = data.get("usage") or {}
    return {
        "text": "\n".join(text_chunks).strip(),
        "sources": sources,
        "usage": {
            "input_tokens": usage.get("total_input_tokens", usage.get("input_tokens")),
            "output_tokens": usage.get("total_output_tokens", usage.get("output_tokens")),
        },
        "provider_response_id": data.get("id"),
    }


def _gemini_tools(web_search: bool, calculator: bool) -> list[dict[str, Any]]:
    tools: list[dict[str, Any]] = []
    if web_search:
        tools.append({"type": "google_search"})
    if calculator:
        tools.append({
            "type": "function",
            "name": CALCULATOR_TOOL_NAME,
            "description": CALCULATOR_DESCRIPTION,
            "parameters": CALCULATOR_PARAMETERS,
        })
    return tools


async def call_gemini(
    *, api_key: str, model: str, system_prompt: str, prompt: str,
    history: list[dict[str, str]], web_search: bool, max_output_tokens: int,
    reasoning_effort: str, timeout: float, enable_calculator: bool = False,
) -> dict[str, Any]:
    initial_input = _history_as_text(history, prompt)
    conversation_steps: list[dict[str, Any]] = [{
        "type": "user_input",
        "content": [{"type": "text", "text": initial_input}],
    }]
    all_sources: list[dict[str, str]] = []
    seen_sources: set[str] = set()
    usage_total = {"input_tokens": 0, "output_tokens": 0}
    used_tools: list[dict[str, Any]] = []
    final_text = ""
    final_id = None
    total_tool_calls = 0
    deadline = time.monotonic() + timeout
    url = "https://generativelanguage.googleapis.com/v1beta/interactions"

    for tool_round in range(MAX_CALCULATOR_CALLS + 1):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ProviderError("gemini", None, "Gemini tool workflow exceeded its total time budget")
        payload: dict[str, Any] = {
            "model": model,
            "system_instruction": system_prompt,
            "input": initial_input if tool_round == 0 else conversation_steps,
            "store": False,
            "generation_config": {
                "max_output_tokens": max_output_tokens,
                "thinking_level": reasoning_effort if reasoning_effort in {"low", "medium", "high"} else "medium",
            },
        }
        tools = _gemini_tools(web_search, enable_calculator and tool_round < MAX_CALCULATOR_CALLS)
        if tools:
            payload["tools"] = tools

        try:
            async with httpx.AsyncClient(timeout=remaining) as client:
                response = await client.post(
                    url,
                    headers={"x-goog-api-key": api_key, "Content-Type": "application/json"},
                    json=payload,
                )
        except httpx.TimeoutException as exc:
            raise ProviderError("gemini", None, "Gemini request timed out; no blind retry was attempted") from exc
        except httpx.HTTPError as exc:
            raise ProviderError("gemini", None, "Could not connect to Gemini") from exc

        if response.is_error:
            raise ProviderError("gemini", response.status_code, f"Gemini returned HTTP {response.status_code}")
        try:
            data = response.json()
        except ValueError as exc:
            raise ProviderError("gemini", response.status_code, "Gemini returned an unreadable response") from exc
        if not isinstance(data, dict):
            raise ProviderError("gemini", response.status_code, "Gemini returned an unexpected response")

        normalized = parse_gemini_interaction(data)
        final_text = normalized["text"]
        final_id = normalized["provider_response_id"] or final_id
        for key in ("input_tokens", "output_tokens"):
            value = normalized["usage"].get(key)
            if isinstance(value, int) and value >= 0:
                usage_total[key] += value
        for source in normalized["sources"]:
            if source["url"] not in seen_sources:
                seen_sources.add(source["url"])
                all_sources.append(source)

        steps = data.get("steps", []) or []
        calls = [step for step in steps if isinstance(step, dict) and step.get("type") == "function_call"]
        if not calls:
            break
        if not enable_calculator or tool_round >= MAX_CALCULATOR_CALLS:
            raise ProviderError("gemini", None, "Gemini requested a tool that AXIOM did not authorize")

        # Stateless Interactions calls require the exact model steps, including signatures, to be resent.
        conversation_steps.extend(steps)
        for call in calls:
            total_tool_calls += 1
            call_id = call.get("id")
            name = call.get("name")
            arguments = call.get("arguments")
            if total_tool_calls > MAX_CALCULATOR_CALLS or name != CALCULATOR_TOOL_NAME or not isinstance(call_id, str):
                result = {"error": "Tool call is not available or the per-request limit was reached"}
            else:
                if isinstance(arguments, str):
                    try:
                        arguments = json.loads(arguments)
                    except json.JSONDecodeError:
                        arguments = None
                result = _calculator_result(arguments)
            used_tools.append({"name": str(name or "unknown"), "ok": "error" not in result})
            conversation_steps.append({
                "type": "function_result",
                "name": str(name or "unknown"),
                "call_id": call_id if isinstance(call_id, str) else "invalid-call-id",
                "result": [{"type": "text", "text": json.dumps(result, ensure_ascii=False, separators=(",", ":"))}],
            })

    return {
        "text": final_text,
        "sources": all_sources,
        "usage": usage_total,
        "provider_response_id": final_id,
        "tools_used": used_tools,
    }
