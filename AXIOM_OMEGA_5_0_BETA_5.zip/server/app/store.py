from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import json
import os
import re
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class StoreError(RuntimeError):
    pass


class IdempotencyConflict(StoreError):
    pass


class PrivateStore:
    """Small single-node SQLite store. Memory and cached responses are AES-GCM encrypted.

    The database stores operational metadata only. Prompts and raw provider outputs are
    not stored in run traces. An encrypted response cache is retained only for the
    configured idempotency TTL, to prevent duplicate paid provider calls on retries.
    """

    def __init__(self, path: str, master_key_b64: str | None, idempotency_ttl: int = 86400):
        self.path = path
        self.idempotency_ttl = idempotency_ttl
        self.key: bytes | None = None
        if master_key_b64:
            try:
                # Strict decoder: urlsafe_b64decode() silently ignores some invalid bytes.
                key = base64.b64decode(
                    master_key_b64 + "=" * (-len(master_key_b64) % 4),
                    altchars=b"-_", validate=True,
                )
            except (ValueError, binascii.Error) as exc:
                raise ValueError("AXIOM_MASTER_KEY must be URL-safe base64") from exc
            if len(key) != 32:
                raise ValueError("AXIOM_MASTER_KEY must decode to exactly 32 bytes")
            self.key = key
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA busy_timeout=10000")
        con.execute("PRAGMA secure_delete=ON")
        return con

    def _init_db(self) -> None:
        with self._connect() as con:
            con.execute("PRAGMA journal_mode=WAL")
            con.executescript(
                """
                CREATE TABLE IF NOT EXISTS memory_items (
                    id TEXT PRIMARY KEY,
                    device_id TEXT NOT NULL,
                    title_enc BLOB NOT NULL,
                    content_enc BLOB NOT NULL,
                    tags_enc BLOB NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS memory_device_idx ON memory_items(device_id, updated_at DESC);
                CREATE TABLE IF NOT EXISTS memory_terms (
                    device_id TEXT NOT NULL,
                    memory_id TEXT NOT NULL REFERENCES memory_items(id) ON DELETE CASCADE,
                    term_hash TEXT NOT NULL,
                    occurrences INTEGER NOT NULL,
                    PRIMARY KEY(memory_id, term_hash)
                );
                CREATE INDEX IF NOT EXISTS memory_terms_lookup_idx ON memory_terms(device_id, term_hash, memory_id);
                CREATE TABLE IF NOT EXISTS schema_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS idempotency (
                    device_id TEXT NOT NULL,
                    idem_key TEXT NOT NULL,
                    body_hash TEXT NOT NULL,
                    state TEXT NOT NULL,
                    response_enc BLOB,
                    request_id TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL,
                    PRIMARY KEY(device_id, idem_key)
                );
                CREATE INDEX IF NOT EXISTS idempotency_expiry_idx ON idempotency(state, created_at);
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY,
                    request_id TEXT NOT NULL,
                    device_id TEXT NOT NULL,
                    provider TEXT NOT NULL,
                    model TEXT NOT NULL,
                    agent TEXT NOT NULL,
                    status TEXT NOT NULL,
                    duration_ms INTEGER NOT NULL DEFAULT 0,
                    input_tokens INTEGER,
                    output_tokens INTEGER,
                    created_at REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS runs_device_idx ON runs(device_id, created_at DESC);
                """
            )
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass
        if self.key:
            self._ensure_memory_term_index()

    def _term_hash(self, device_id: str, term: str) -> str:
        if not self.key:
            raise StoreError("Encrypted storage is not configured; set AXIOM_MASTER_KEY")
        # A separate derived key per device prevents equality correlation across devices.
        index_key = hmac.new(
            self.key, b"axiom-memory-term-index-v2:" + device_id.encode("utf-8"), hashlib.sha256
        ).digest()
        return hmac.new(index_key, term.encode("utf-8"), hashlib.sha256).hexdigest()

    @staticmethod
    def _term_counts(text: str) -> dict[str, int]:
        words = re.findall(r"[\wÀ-ž]{2,}", text.casefold())
        counts: dict[str, int] = {}
        for word in words[:10000]:
            counts[word] = min(255, counts.get(word, 0) + 1)
        return counts

    def _index_memory(self, con: sqlite3.Connection, device_id: str, memory_id: str,
                      title: str, content: str, tags: list[str]) -> None:
        counts = self._term_counts(" ".join([title, content, *tags]))
        rows = [(device_id, memory_id, self._term_hash(device_id, term), count) for term, count in counts.items()]
        con.executemany(
            "INSERT OR REPLACE INTO memory_terms(device_id,memory_id,term_hash,occurrences) VALUES(?,?,?,?)",
            rows,
        )

    def _ensure_memory_term_index(self) -> None:
        """Rebuild the per-device HMAC index atomically when its derivation changes."""
        with self._connect() as con:
            marker = con.execute("SELECT value FROM schema_meta WHERE key='memory_term_index_v2'").fetchone()
            if marker and marker[0] == "done":
                return
            con.execute("BEGIN IMMEDIATE")
            try:
                # v1 used a different derivation. Remove old hashes before rebuilding so
                # stale index entries cannot survive an upgrade or become false matches.
                con.execute("DELETE FROM memory_terms")
                rows = con.execute("SELECT * FROM memory_items").fetchall()
                for row in rows:
                    # Decrypting during migration ensures index terms are never derived from
                    # plaintext supplied by a different or missing master key.
                    device_id, memory_id = row["device_id"], row["id"]
                    title = self._decrypt(row["title_enc"], f"memory:title:{device_id}:{memory_id}")
                    content = self._decrypt(row["content_enc"], f"memory:content:{device_id}:{memory_id}")
                    tags = self._decrypt(row["tags_enc"], f"memory:tags:{device_id}:{memory_id}")
                    self._index_memory(con, device_id, memory_id, title, content, tags)
                con.execute(
                    "INSERT INTO schema_meta(key,value) VALUES('memory_term_index_v2','done') "
                    "ON CONFLICT(key) DO UPDATE SET value='done'"
                )
                con.commit()
            except Exception:
                con.rollback()
                raise

    def _encrypt(self, value: Any, purpose: str) -> bytes:
        if not self.key:
            raise StoreError("Encrypted storage is not configured; set AXIOM_MASTER_KEY")
        nonce = os.urandom(12)
        plaintext = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return nonce + AESGCM(self.key).encrypt(nonce, plaintext, purpose.encode("utf-8"))

    def _decrypt(self, value: bytes, purpose: str) -> Any:
        if not self.key:
            raise StoreError("Encrypted storage is not configured; set AXIOM_MASTER_KEY")
        raw = bytes(value)
        plaintext = AESGCM(self.key).decrypt(raw[:12], raw[12:], purpose.encode("utf-8"))
        return json.loads(plaintext.decode("utf-8"))

    def require_encryption(self) -> None:
        if not self.key:
            raise StoreError("Encrypted storage is not configured; set AXIOM_MASTER_KEY")

    def add_memory(self, device_id: str, title: str, content: str, tags: list[str]) -> dict[str, Any]:
        self.require_encryption()
        item_id = str(uuid.uuid4())
        now = time.time()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            count = con.execute("SELECT COUNT(*) FROM memory_items WHERE device_id=?", (device_id,)).fetchone()[0]
            if count >= 2000:
                raise StoreError("Memory limit reached (2000 items per device)")
            con.execute(
                "INSERT INTO memory_items VALUES(?,?,?,?,?,?,?)",
                (item_id, device_id, self._encrypt(title, f"memory:title:{device_id}:{item_id}"),
                 self._encrypt(content, f"memory:content:{device_id}:{item_id}"), self._encrypt(tags, f"memory:tags:{device_id}:{item_id}"), now, now),
            )
            self._index_memory(con, device_id, item_id, title, content, tags)
        return {"id": item_id, "title": title, "tags": tags, "created_at": now, "chars": len(content)}

    def list_memory(self, device_id: str, limit: int = 100) -> list[dict[str, Any]]:
        self.require_encryption()
        with self._connect() as con:
            rows = con.execute(
                "SELECT * FROM memory_items WHERE device_id=? ORDER BY updated_at DESC LIMIT ?",
                (device_id, max(1, min(limit, 200))),
            ).fetchall()
        out = []
        for row in rows:
            title = self._decrypt(row["title_enc"], f"memory:title:{device_id}:{row['id']}")
            tags = self._decrypt(row["tags_enc"], f"memory:tags:{device_id}:{row['id']}")
            out.append({"id": row["id"], "title": title, "tags": tags, "created_at": row["created_at"],
                        "updated_at": row["updated_at"]})
        return out

    def search_memory(self, device_id: str, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Search encrypted memories through a keyed HMAC term index.

        The index does not store plaintext words, but equal terms produce equal
        hashes within this database. Treat the database and its master key as secrets.
        """
        self.require_encryption()
        terms = list(dict.fromkeys(re.findall(r"[\wÀ-ž]{2,}", query.casefold())))[:16]
        if not terms:
            return []
        hashes = [self._term_hash(device_id, term) for term in terms]
        placeholders = ",".join("?" for _ in hashes)
        with self._connect() as con:
            matches = con.execute(
                f"SELECT memory_id, SUM(occurrences) AS score FROM memory_terms "
                f"WHERE device_id=? AND term_hash IN ({placeholders}) "
                "GROUP BY memory_id ORDER BY score DESC LIMIT 100",
                (device_id, *hashes),
            ).fetchall()
            if not matches:
                return []
            by_id = {row["memory_id"]: int(row["score"]) for row in matches}
            ids = list(by_id)
            id_placeholders = ",".join("?" for _ in ids)
            rows = con.execute(
                f"SELECT * FROM memory_items WHERE device_id=? AND id IN ({id_placeholders})",
                (device_id, *ids),
            ).fetchall()
        ranked = []
        for row in rows:
            title = self._decrypt(row["title_enc"], f"memory:title:{device_id}:{row['id']}")
            content = self._decrypt(row["content_enc"], f"memory:content:{device_id}:{row['id']}")
            tags = self._decrypt(row["tags_enc"], f"memory:tags:{device_id}:{row['id']}")
            hay = f"{title} {content} {' '.join(tags)}".casefold()
            score = by_id[row["id"]]
            if query.casefold() in hay:
                score += 8
            ranked.append((score, row["updated_at"], {
                "id": row["id"], "title": title, "content": content[:12000], "tags": tags,
                "score": score, "created_at": row["created_at"],
            }))
        ranked.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return [x[2] for x in ranked[:max(1, min(limit, 10))]]

    def delete_memory(self, device_id: str, item_id: str | None = None) -> int:
        with self._connect() as con:
            if item_id:
                cur = con.execute("DELETE FROM memory_items WHERE device_id=? AND id=?", (device_id, item_id))
            else:
                cur = con.execute("DELETE FROM memory_items WHERE device_id=?", (device_id,))
            return cur.rowcount

    def begin_idempotency(self, device_id: str, idem_key: str, body_hash: str, request_id: str):
        now = time.time()
        with self._connect() as con:
            con.execute("BEGIN IMMEDIATE")
            # Expire cached response bodies, but keep a small tombstone so an old
            # retry button can never re-dispatch a paid request after the cache TTL.
            con.execute(
                "UPDATE idempotency SET state='expired', response_enc=NULL, updated_at=? "
                "WHERE created_at < ? AND state='completed'",
                (now, now - self.idempotency_ttl),
            )
            # A process may crash while a request is pending. Never reclaim such a key
            # for a fresh provider call: mark it ambiguous after the TTL instead.
            con.execute(
                "UPDATE idempotency SET state='ambiguous', response_enc=NULL, updated_at=? "
                "WHERE created_at < ? AND state='pending'",
                (now, now - self.idempotency_ttl),
            )
            # Commit cache-body expiry separately; later conflict exceptions must
            # not roll the tombstone back and accidentally retain an old response.
            con.commit()
            con.execute("BEGIN IMMEDIATE")
            row = con.execute(
                "SELECT * FROM idempotency WHERE device_id=? AND idem_key=?", (device_id, idem_key)
            ).fetchone()
            if row:
                if row["body_hash"] != body_hash:
                    raise IdempotencyConflict("Idempotency-Key was already used for a different request")
                if row["state"] == "completed":
                    cached = self._decrypt(row["response_enc"], f"idempotency:response:{device_id}:{idem_key}") if row["response_enc"] else None
                    if cached is None:
                        raise IdempotencyConflict("Request was already processed; cached result is unavailable. Do not retry automatically.")
                    return {"cached": cached, "state": "completed"}
                if row["state"] == "expired":
                    raise IdempotencyConflict("The cached response expired. This key is retained to prevent a duplicate paid request; do not reuse it.")
                raise IdempotencyConflict("An identical request is already in progress or has an ambiguous provider result. Do not retry automatically.")
            con.execute(
                "INSERT INTO idempotency(device_id,idem_key,body_hash,state,response_enc,request_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                (device_id, idem_key, body_hash, "pending", None, request_id, now, now),
            )
            return {"cached": None, "state": "pending"}

    def complete_idempotency(self, device_id: str, idem_key: str, response: dict[str, Any]) -> None:
        encrypted = self._encrypt(response, f"idempotency:response:{device_id}:{idem_key}") if self.key else None
        with self._connect() as con:
            con.execute(
                "UPDATE idempotency SET state='completed', response_enc=?, updated_at=? WHERE device_id=? AND idem_key=?",
                (encrypted, time.time(), device_id, idem_key),
            )

    def mark_idempotency_ambiguous(self, device_id: str, idem_key: str) -> None:
        with self._connect() as con:
            con.execute(
                "UPDATE idempotency SET state='ambiguous', updated_at=? WHERE device_id=? AND idem_key=?",
                (time.time(), device_id, idem_key),
            )

    def record_run(self, *, request_id: str, device_id: str, provider: str, model: str, agent: str,
                   status: str, duration_ms: int, usage: dict[str, Any] | None = None) -> None:
        usage = usage or {}
        with self._connect() as con:
            con.execute(
                "INSERT INTO runs VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), request_id, device_id, provider, model, agent, status, duration_ms,
                 usage.get("input_tokens"), usage.get("output_tokens"), time.time()),
            )

    def list_runs(self, device_id: str, limit: int = 50) -> list[dict[str, Any]]:
        with self._connect() as con:
            rows = con.execute(
                "SELECT request_id,provider,model,agent,status,duration_ms,input_tokens,output_tokens,created_at "
                "FROM runs WHERE device_id=? ORDER BY created_at DESC LIMIT ?",
                (device_id, max(1, min(limit, 100))),
            ).fetchall()
        return [dict(row) for row in rows]

    def usage_summary(self, device_id: str) -> dict[str, Any]:
        with self._connect() as con:
            row = con.execute(
                "SELECT COUNT(*) AS calls, COALESCE(SUM(input_tokens),0) AS input_tokens, "
                "COALESCE(SUM(output_tokens),0) AS output_tokens FROM runs WHERE device_id=? AND status='completed'",
                (device_id,),
            ).fetchone()
        return dict(row)
