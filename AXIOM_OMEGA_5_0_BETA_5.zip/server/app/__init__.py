"""AXIOM OMEGA private server."""
