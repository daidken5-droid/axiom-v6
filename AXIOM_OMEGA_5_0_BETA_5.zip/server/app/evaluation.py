from __future__ import annotations

from typing import Any
from urllib.parse import urlsplit


def evaluate_output(text: str, sources: list[dict[str, Any]], web_search_requested: bool) -> dict[str, Any]:
    """Structural checks only; this does not independently prove factual correctness."""
    clean_text = bool(isinstance(text, str) and text.strip())
    safe_sources = []
    for source in sources or []:
        url = source.get("url") if isinstance(source, dict) else None
        if not isinstance(url, str) or len(url) > 2048:
            continue
        try:
            parsed = urlsplit(url)
            if parsed.scheme == "https" and parsed.hostname and parsed.username is None and parsed.password is None:
                safe_sources.append(source)
        except ValueError:
            continue
    warnings: list[str] = []
    if not clean_text:
        warnings.append("provider_returned_empty_text")
    if web_search_requested and not safe_sources:
        warnings.append("web_search_requested_but_no_clickable_sources_returned")
    return {
        "structurally_valid": clean_text,
        "source_count": len(safe_sources),
        "web_search_requested": web_search_requested,
        "warnings": warnings,
        "factual_verification": "not_performed",
    }
