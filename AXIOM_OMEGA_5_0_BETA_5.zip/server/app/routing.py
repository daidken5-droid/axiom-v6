from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

Provider = Literal["openai", "gemini"]


@dataclass(frozen=True)
class Route:
    provider: Provider
    model: str
    reasoning_effort: str
    reason: str


HIGH_PATTERNS = re.compile(
    r"\b(architect|architecture|debug|refactor|security review|threat model|" 
    r"complex|comprehensive|deep research|compare alternatives|multi[- ]step|" 
    r"strateg(y|ic)|návrh architektury|programov|zabezpeč|hloubkov|komplex|" 
    r"porovnej možnosti|vícekrok|rešerš)\b",
    re.IGNORECASE,
)
FAST_PATTERNS = re.compile(
    r"\b(translate|translation|summari[sz]e|rewrite|classify|extract|" 
    r"přelož|shrň|přepiš|vytáhni|klasifikuj)\b",
    re.IGNORECASE,
)


def classify_task(prompt: str, agent: str | None = None) -> str:
    text = prompt.strip()
    if HIGH_PATTERNS.search(text) or agent in {"audit", "research"} or len(text) > 4500:
        return "high"
    if FAST_PATTERNS.search(text) and len(text) < 5000:
        return "fast"
    if len(text) < 350:
        return "fast"
    return "standard"


def choose_route(
    *, prompt: str, provider_choice: str, agent: str | None,
    use_web_search: bool, openai_available: bool, gemini_available: bool,
    settings,
) -> Route:
    complexity = classify_task(prompt, agent)
    if provider_choice == "openai":
        provider: Provider = "openai"
    elif provider_choice == "gemini":
        provider = "gemini"
    elif provider_choice == "auto":
        # Prefer Gemini for ordinary grounded lookups and OpenAI for general
        # reasoning. If the preferred provider is not configured, choose the
        # other configured provider before failing closed.
        preferred: Provider = "gemini" if use_web_search and complexity != "high" else "openai"
        if preferred == "gemini" and not gemini_available and openai_available:
            provider = "openai"
        elif preferred == "openai" and not openai_available and gemini_available:
            provider = "gemini"
        else:
            provider = preferred
    else:
        raise ValueError("Unsupported provider choice")

    if provider == "openai":
        if not openai_available:
            raise RuntimeError("OpenAI is not configured on this server")
        if complexity == "high":
            return Route(provider, settings.openai_reasoning_model, "high", "high-complexity task")
        if complexity == "fast":
            return Route(provider, settings.openai_fast_model, "low", "short or routine task")
        return Route(provider, settings.openai_primary_model, "medium", "balanced default route")

    if not gemini_available:
        raise RuntimeError("Gemini is not configured on this server")
    if complexity == "high":
        return Route(provider, settings.gemini_reasoning_model, "high", "high-complexity task")
    return Route(provider, settings.gemini_primary_model, "low" if complexity == "fast" else "medium", "Gemini route for grounded lookup or selected provider")
