from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from threading import Lock

from fastapi import HTTPException, Request, status


@dataclass(frozen=True)
class Device:
    device_id: str


def issue_device_token() -> tuple[str, str]:
    """Return one-time plaintext token and its SHA-256 hash for server config."""
    token = "axm_" + secrets.token_urlsafe(36)
    return token, hashlib.sha256(token.encode("utf-8")).hexdigest()


def authenticate_token(raw_token: str | None, configured: dict[str, str]) -> Device:
    if not raw_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing device token")
    candidate = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
    for device_id, expected_hash in configured.items():
        if hmac.compare_digest(candidate, expected_hash.lower()):
            return Device(device_id=device_id)
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid device token")


class SlidingWindowLimiter:
    """Single-process limiter. Use Redis-backed limiting before scaling to >1 worker."""

    def __init__(self, limit: int, window_seconds: int = 60):
        self.limit = limit
        self.window_seconds = window_seconds
        self._events: dict[str, deque[float]] = defaultdict(deque)
        self._lock = Lock()

    def check(self, key: str) -> None:
        now = time.monotonic()
        with self._lock:
            events = self._events[key]
            while events and now - events[0] >= self.window_seconds:
                events.popleft()
            if len(events) >= self.limit:
                raise HTTPException(status_code=429, detail="Rate limit reached; retry later")
            events.append(now)
