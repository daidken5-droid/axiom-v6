# AXIOM OMEGA 5.0.0 Beta 1

## Server
- Consolidated adaptive OpenAI Responses / Gemini Interactions adapters.
- Added encrypted, device-scoped memory and authenticated-encryption associated data.
- Added idempotency for paid requests, explicit cloud/compare/memory consent and metadata-only run traces.
- Added HADES structural checks for non-empty model output and HTTPS sources (not factual verification).
- Added safe calculator, PWA client and offline shell cache.
- Added provider/usage/capability metadata.

## Android source
- Added a new Android Studio project with secure WebView asset origin.
- Added Android Keystore-backed device-token store and a narrow JavaScript bridge.
- Added HTTPS-only OkHttp requests with redirects disabled.
- Added background-thread GGUF file import to private storage, incremental SHA-256, GGUF magic check and atomic rename.
- Reused the arm64 JNI library from the original user-supplied 2.1 APK; native sources were not supplied.
- Added monochrome adaptive Android launcher icon and offline mode selector.
- Added local TXT/Markdown knowledge library using private SQLite FTS4 (100 files / 10 MB each / 256 MB total), with a separate consent gate before excerpts are sent to cloud providers.

## Limitations
- No APK has been built in this environment because Android SDK/Gradle tooling is unavailable.
- No real VPS, OpenAI or Gemini API connection was provisioned or tested.
- Native GGUF import/inference and device performance require testing on Pixel 10a.
- No streaming UI, vector memory, autonomous tool loop or factuality benchmark yet.
