# AXIOM OMEGA Server 4.0.1

- Gemini adapter migrated from legacy `generateContent` to the current Interactions API endpoint.
- Gemini web search uses the `google_search` tool and citations are normalized from `model_output` URL annotations.
- Gemini interactions set `store: false` to avoid retaining interaction history for retrieval.
- Rejects unsafe/non-HTTP citation URLs and deduplicates sources.
- Adds maximum combined prompt/history/system-hint size.
- Adds configuration-based auto-routing to the only configured provider when the preferred provider is unavailable before dispatch.
- Runtime cross-provider retries remain disabled to prevent duplicate charges and unintended data disclosure.
- API documentation endpoints are disabled by default in production.
- Adds container resource/PID limits and waits for API health before starting Caddy.
- Adds tests for Gemini response normalization and one-provider auto-routing.

This is a backend-only update. It does not modify or rebuild the AXIOM Android APK.
