# AXIOM OMEGA Private API — Beta 5

FastAPI backend pro privátní AXIOM klient. API klíče OpenAI a Gemini zůstávají na serveru.

## Funkce

- OpenAI Responses API (`store:false`) a Gemini Interactions API (`store:false`).
- Provider-hosted web search; vybrané modely a model ID v `.env`.
- RANDY: jednoduché vysvětlitelné směrování podle typu úkolu.
- Explicitní souhlas s cloudem, compare režimem, serverovou pamětí a místními úryvky.
- AES-GCM serverová paměť, per-device HMAC term index v2.
- Idempotency key, šifrovaná cache dokončené odpovědi, tombstones po TTL a zákaz redispatch stale/ambiguous requestů.
- Bezpečná aritmetická kalkulačka s omezeným tool-calling loop (max. 2 volání na provider request).
- Metadata-only run/usage traces.
- PWA klient pod stejným originem.

## Lokální vývoj

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
pytest -q
uvicorn app.main:app --reload
```

Pro veřejné nasazení nepoužívej `--reload`. Použij Docker Compose + Caddy podle `docs/DEPLOY_CZ.md`.

## Provozní limity

- Jediný worker/proces; SQLite + in-memory rate limiter. Více replik vyžaduje Redis a přehodnocení databáze.
- HADES je strukturální kontrola, ne fact-check.
- Místní HMAC index je lexikální, nikoli sémantický/vektorový.
- Requesty vyžadují `Idempotency-Key` a šifrovací `AXIOM_MASTER_KEY`.
- Nejasný stav provider volání se nikdy automaticky neopakuje.
- Nejsou implementovány streaming, obrázky ani obecný agentní shell/API nástroje.

Viz `docs/SECURITY_MODEL.md`, `docs/ARCHITECTURE.md` a `docs/DEPLOY_CZ.md`.
