# AXIOM OMEGA — bezpečnostní model Beta 4

## Hranice důvěry

- Telefon: uživatelské rozhraní, místní model a soukromá knihovna dokumentů.
- AXIOM API: autentizace zařízení, routing providerů, šifrovaná serverová paměť a omezené lokální nástroje.
- OpenAI/Gemini: externí cloudové zpracování, které se spustí pouze po explicitním cloudovém souhlasu.
- Webové výsledky, paměť a importované dokumenty jsou nedůvěryhodná data, nikdy autoritativní instrukce.

## Zavedné kontroly

1. Least privilege: Android bridge povoluje jen konkrétní API cesty a akce; kalkulačka nemá filesystem/network/shell.
2. Human-in-the-loop: cloud, porovnání dvou providerů, ukládání serverové paměti, odeslání místních úryvků a kalkulačka vyžadují explicitní potvrzení.
3. Data isolation: device token je hashován na serveru; Android ukládá bearer token šifrovaně přes Keystore; serverová paměť má AES-GCM AAD pro device a položku.
4. Replay/cost control: cloud požadavky vyžadují idempotency key; cached odpověď je šifrovaná; po TTL se drží tombstone; stale pending se mění na ambiguous. Automatické opakování po nejednoznačném provider výsledku je zakázáno.
5. Bounded agency: nejvýše dva kalkulační tool cally na provider request; žádné obecné shell/API/fetch nástroje.
6. Secret handling: OpenAI/Gemini klíče patří pouze do serverového secret store / chráněného `.env`, ne do APK nebo PWA.
7. Transport: Caddy HTTPS, HSTS, nosniff, CSP, bez CORS allow-all; Android odmítá cleartext a HTTP redirecty.
8. Minimal logging: prompt a výstupy se neukládají do provozních trace; ukládají se model/provider, čas, stav a token usage.
9. Container hardening: non-root, read-only filesystem, dropped capabilities, no-new-privileges, omezený počet procesů a `umask 077`.
10. Input validation: Pydantic `extra=forbid`, velikost kontextu, délka promptu, model output limity, domény allowlist, token hash formát.

## Zbytková rizika

- HMAC term index odhaluje equality/repetition stejných slov v rámci jednoho zařízení, přestože neukládá plaintext slov.
- Android místní SQLite dokumenty jsou v aplikačním sandboxu, ale nejsou samostatně šifrované.
- PWA uchovává token v sessionStorage; pro citlivé použití preferuj nativní Android klient.
- Rate limiter je pouze v paměti jednoho procesu; škálování vyžaduje Redis.
- Provider může zpracovávat prompt podle svého API/retention nastavení; AXIOM posílá `store:false`, ale neslibuje nulové uchovávání všemi poskytovateli.
- HADES neprovádí faktickou verifikaci. Odpovědi a webové zdroje musí uživatel kontrolovat.
- Neexistují nezávislé red-team testy ani audit třetí stranou.

## Produkční bezpečnostní pravidla

- Nezpřístupňuj interní `/docs` na veřejném serveru.
- Nezapínej logování request bodies na proxy.
- Povol SSH pouze z důvěryhodné IP, používej klíče, ne hesla.
- Zálohuj master key mimo VPS, šifrovaně. Ztráta klíče znamená ztrátu dešifrovatelnosti serverové paměti a cache.
- Ukládej API klíče ve správci tajemství, pokud jej VPS nabízí.
- Při podezření na únik rotuj device token i provider keys.
- Před přidáním nového nástroje vyžaduj allowlist, limit rozpočtu, lidské potvrzení pro vedlejší efekty a adversariální testy.

Zásady vycházejí mimo jiné z OWASP AI Agent Security Cheat Sheet a Top 10 for Agentic Applications: https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html a https://genai.owasp.org/2025/12/09/owasp-genai-security-project-releases-top-10-risks-and-mitigations-for-agentic-ai-security/ .
