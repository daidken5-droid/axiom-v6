# AXIOM OMEGA 5.0.0 Beta 4 — nasazení na VPS

Tento postup nasazuje serverovou část. Android klient se sestavuje zvlášť z `android-app/`.

## 1. VPS a DNS

Pro soukromé použití doporučuji Ubuntu 24.04 LTS nebo Debian 12, 2–4 vCPU, 4–8 GB RAM a alespoň 30 GB SSD/NVMe. Server nehostuje lokální jazykový model; provádí autentizaci, routování, databázi a volání cloudových providerů.

1. Založ VPS u vybraného poskytovatele.
2. Nastav DNS A záznam subdomény na veřejnou IPv4 VPS. AAAA přidej jen po ověření funkčního IPv6.
3. Firewall: SSH pouze z důvěryhodné IP, TCP 80 a 443.
4. DNS musí být veřejně funkční před spuštěním Caddy; Let's Encrypt potřebuje dostupné porty 80/443.

## 2. Nainstaluj Docker

Nainstaluj Docker Engine a Compose plugin podle oficiální dokumentace https://docs.docker.com/engine/install/ . Ověř `docker --version` a `docker compose version`.

## 3. Nahraj server

Z projektového ZIPu zkopíruj obsah `server/` do `/opt/axiom-omega`:

```bash
sudo mkdir -p /opt/axiom-omega
sudo chown "$USER":"$USER" /opt/axiom-omega
# nahraj serverovou složku do /opt/axiom-omega
cd /opt/axiom-omega
cp .env.example .env
chmod 600 .env
```

## 4. Vygeneruj tajné hodnoty přímo na VPS

Master key:

```bash
python3 scripts/generate_master_key.py
```

Vlož hodnotu do `AXIOM_MASTER_KEY` a ulož šifrovanou offline zálohu odděleně od VPS. Bez ní nepůjde dešifrovat serverová paměť ani idempotency cache.

Device token:

```bash
python3 scripts/create_device_token.py pixel10a
```

Skript jednorázově zobrazí plaintext token a SHA-256 hash. Plaintext přenes bezpečně do telefonu; do `AXIOM_DEVICE_TOKENS_JSON` vlož pouze hash, například `{"pixel10a":"<sha256>"}`.

Vyplň také:

- `AXIOM_DOMAIN` — skutečnou veřejnou doménu.
- `AXIOM_ALLOWED_HOSTS` — explicitní názvy/IP; wildcard `*` je zakázán.
- `OPENAI_API_KEY` a `GEMINI_API_KEY` — pouze na serveru.
- modely a limity podle skutečné dostupnosti účtu a API projektu.

API klíče jsou samostatné od běžných spotřebitelských plánů ChatGPT/Gemini. Nikdy je nevkládej do APK ani do chatu.

## 5. Ověř a spusť

```bash
python3 scripts/validate_env.py .env

docker compose config
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 axiom-api
```

Ověř `https://TVA-DOMENA/health` a `https://TVA-DOMENA/ready`. Readiness vyžaduje master key, alespoň jednoho providera a alespoň jeden device token.

## 6. Provozní bezpečnost

- Zálohuj `.env`, `AXIOM_MASTER_KEY` a data volume šifrovaně a odděleně od VPS.
- Rotuj device tokeny a provider klíče při podezření na únik.
- Request-body logging je zakázaný; Uvicorn access log je vypnutý, protože URL hledání paměti může obsahovat osobní dotazy.
- API docs jsou ve výchozím stavu vypnuté; na veřejném serveru je nezapínej.
- Rate limiter je in-memory a vhodný pro jednu instanci/worker. Více workerů vyžaduje Redis a sdílený limiter.
- Odpověď z idempotency cache je šifrovaná pouze po TTL. Po expiraci zůstává malý tombstone; stale pending se mění na ambiguous. Tombstones rostou s počtem unikátních cloudových požadavků.
- Monitoruj dostupnost, disk, RAM, náklady providerů a zálohy.
- Docker API kontejner běží non-root, read-only, bez capabilities a s `umask 077`; přístup ke `.env` má jen správce serveru.

## 7. Testy

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
pytest -q
python -m compileall -q app scripts
```

Testy neprovádějí živá volání providerů a nevytvářejí API náklady. Reálné API otestuj až po nastavení limitu nákladů.
