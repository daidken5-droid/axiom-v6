# AXIOM OMEGA Beta 4 — produkční checklist

## Server
- [ ] VPS Ubuntu 24.04 / Debian 12 a pravidelně aktualizovaný systém.
- [ ] Doména a DNS A/AAAA; IPv6 pouze po ověření.
- [ ] SSH klíč, omezení SSH na vlastní IP, firewall 80/443/SSH.
- [ ] Docker Engine + Compose plugin z oficiálního repozitáře.
- [ ] `.env` s chmod 600; validace `python3 scripts/validate_env.py .env`.
- [ ] Master key zálohovaný šifrovaně mimo VPS.
- [ ] Unikátní device token pro Pixel; na serveru pouze SHA-256 hash.
- [ ] OpenAI/Gemini API klíče v serverovém secret store nebo `.env`; nikdy v APK.
- [ ] `docker compose config`, `docker compose up -d --build`, `/health` a `/ready`.
- [ ] Test TLS certifikátu, expirace a obnovy.
- [ ] Test zálohy SQLite a obnovy master key.
- [ ] Ověřit monitoring disk/RAM/CPU, náklady providerů a limity API.
- [ ] Request-body logging vypnutý; API docs vypnuté.

## Android / Pixel 10a
- [ ] Gradle Sync s JDK 17, AGP 8.9.2, Gradle 8.11.1, SDK 35.
- [ ] Debug APK sestavené a instalované na testovací zařízení.
- [ ] Ověřen device token přes Android Keystore a HTTPS připojení.
- [ ] Test OpenAI / Gemini / compare s reálnými testovacími klíči a limitem nákladů.
- [ ] Test odmítnutí cloud consent, memory consent a local-document consent.
- [ ] Import testovacího GGUF souboru: zrušení, nedostatek místa, chybná hlavička, přerušení a SHA-256.
- [ ] Lokální inference s konkrétním modelem; měření RAM/teploty/baterie.
- [ ] Test rotace device tokenu, odpojení serveru a zachování lokálních dat.
- [ ] Release APK podepsané vlastním produkčním klíčem a kontrola SHA-256.

## Release gate

Nesmí být označeno jako produkční, dokud neprojdou všechny povinné body serveru a Androidu. Beta 4 je zatím pouze zdrojový build a automatické testy.
