# AXIOM OMEGA 5.0 Beta 4 — architektura

```text
Android client (Pixel 10a, ARM64)
  ├─ WebView/PWA UI assets (single source synced with server/web)
  ├─ Android Keystore: device bearer token
  ├─ LocalInferenceEngine
  │    └─ LegacyLlamaCppEngine -> existing libaxiom.so from APK 2.1
  ├─ ModelImporter: streaming GGUF → app-private files/models
  ├─ Local SQLite FTS4 TXT/Markdown library
  └─ HTTPS-only, redirect-disabled API client
       │
       ▼
Caddy TLS / CSP / security headers / 256KB request limit
  │
  ▼
FastAPI (single worker)
  ├─ device SHA-256 authentication + rate limit
  ├─ RANDY deterministic route heuristic
  ├─ OpenAI Responses API (store=false) + web_search
  ├─ Gemini Interactions API (store=false) + google_search
  ├─ explicit cloud / compare / memory / local-context consent
  ├─ HADES output/source structure checks
  ├─ AES-GCM encrypted server memory + per-device HMAC term index v2
  ├─ encrypted idempotency response cache + expired/ambiguous tombstones
  ├─ metadata-only run and token-usage traces
  └─ AST-based arithmetic tool (max 2 calls/provider/request)
```

## Data and trust boundaries

- The Android client sends cloud content only after explicit cloud consent. `provider=local` is never forwarded to the server.
- OpenAI/Gemini credentials exist only in server environment/secrets.
- Native Android stores a device token encrypted using Android Keystore AES-GCM. JavaScript does not receive the plaintext token. The browser-only PWA uses sessionStorage for its token and is less suitable for sensitive work.
- OpenAI Responses and Gemini Interactions requests are stateless (`store=false`). AXIOM still sends the prompt and user-approved context to the selected provider; this is not a guarantee that the provider retains no operational data.
- Server memory fields use AES-GCM with device/item-specific authenticated additional data. HMAC search terms are derived from a per-device key. The index stores no plaintext words, but equal terms create equal hashes within a device; protect the database and master key.
- Idempotency response cache stores the completed response encrypted for the configured TTL. At expiry, only a tombstone remains to stop a late retry from re-running the paid action. Stale `pending` requests become `ambiguous`, never reusable. Tombstone metadata accumulates and should be included in DB backups/retention planning.
- `/v1/*` responses are `Cache-Control: no-store`. Uvicorn access logging is disabled to avoid logging paths with user memory-search terms. Caddy does not enable access logging.
- Request bodies and provider outputs are not written to run traces. Usage metadata, provider/model, status and duration are retained.
- Local TXT/Markdown excerpts stay on-device until the user selects and confirms the exact context to be sent to cloud. The local SQLite database is in app-private storage but is not independently encrypted in this beta.
- Web search results, imported files and memory snippets are untrusted data, not privileged instructions.

## RANDY routing

The router is deterministic and rule-based. It classifies short/routine work as fast, general work as standard, and research/audit/long or high-complexity requests as reasoning. For ordinary web lookup it may prefer Gemini when available; other defaults can use OpenAI. Explicit provider selection is never silently switched after dispatch. There is no learned routing model or quality/cost benchmark proving it is optimal.

## HADES

HADES currently checks nonempty output, safe HTTPS URLs, and warns if web search was requested but no clickable URLs were returned. It does not independently verify facts, domain credibility, quote attribution, source freshness or reasoning correctness. The UI must not call this a fact-check.

## Tools and agent autonomy

The sole provider-callable AXIOM tool is the arithmetic-only calculator. It uses Python AST allowlisting, numeric bounds and no shell/network/files/account access. It is exposed only after user opt-in and is capped at two tool calls per provider request. Modes `answer`, `research`, `writer`, and `audit` are single-call instruction profiles; this beta does not implement an open-ended multi-agent loop. New tools need strict schemas, least privilege, per-tool budgets, human confirmation for side effects, and adversarial tests before activation.

## Memory

Server memory is opt-in. Stored fields are AES-GCM encrypted and bound to device/item IDs via AAD. Search uses per-device HMAC term hashes (migration v2), phrase-match boost and a bounded candidate list. It is lexical, not semantic or vector retrieval. The next milestone is local embedding search benchmarked on the Pixel before uploading any personal library to the server.

## Local inference

The project uses a `LocalInferenceEngine` interface. The only current implementation is `LegacyLlamaCppEngine`, wrapping the JNI ABI recovered from the supplied APK 2.1. The original C/C++ sources are not available and only `arm64-v8a` is included. GGUF import checks file extension, size, available storage, SHA-256, magic, version 2/3 and basic header counts. Hashing ensures the copied file is unchanged during import; it does not authenticate publisher provenance. Exact model compatibility and actual inference require a physical Pixel test.

Google LiteRT-LM is documented as a future runtime option for Android with CPU/GPU/NPU acceleration, tool calling and support for Gemma and other families. Gemma 4 E2B/E4B and EmbeddingGemma are not included in this beta. Add a separate adapter after benchmarking cold start, peak RAM, tokens/sec, time-to-first-token, heat and battery on the target Pixel. See `LOCAL_RUNTIME_DECISION.md`.

## Production limitations

- One worker and one VPS instance only. Rate limiting is process-local. For horizontal scale, use Redis or another shared limiter and revisit SQLite.
- No streamed token response, image upload, vector memory, general-purpose autonomous tool chains or server-hosted LLM weights.
- No live provider, VPS, TLS or physical Android tests have been performed in this build environment.
