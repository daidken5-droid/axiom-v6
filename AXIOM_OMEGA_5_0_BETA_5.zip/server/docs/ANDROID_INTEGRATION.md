# Android integration — AXIOM OMEGA 5.0.0 Beta 4

Projekt má Android Studio modul `android-app/`, lokální WebView asset bundle a omezený nativní most.

## Implementováno ve zdrojovém kódu

1. `MainActivity` zobrazuje `assets/web/index.html` přes `WebViewAssetLoader` na důvěryhodném originu `appassets.androidplatform.net`.
2. JavaScript bridge vystavuje allowlist akcí: connect/disconnect, schválené API požadavky, model status/import, místní generování a lokální dokumenty. Bearer token se nepředává JavaScriptu.
3. `SecureDeviceStore` šifruje device token přes AES-GCM klíč v Android Keystore.
4. Serverová URL musí být HTTPS; přesměrování jsou v OkHttp zakázána.
5. `ModelImporter` kopíruje vybraný `.gguf` po 1MiB blocích do privátního úložiště na `Dispatchers.IO`, kontroluje místo, počítá SHA-256, ověřuje GGUF magic, verzi 2/3 a základní hlavičku 24B. Po kopii přejmenuje soubor atomicky v rámci stejné složky.
6. `LocalInferenceEngine` odděluje orchestrace od runtime. `LegacyLlamaCppEngine` volá JNI ABI `Offline.cancel()` a `Offline.generate(String,String)` z původního APK 2.1.
7. `LocalKnowledgeStore` importuje TXT/Markdown do soukromé SQLite FTS4 knihovny. Lokální úryvky lze připojit ke cloudovému požadavku až po samostatném potvrzení se zobrazením odesílaných výňatků.
8. `server/web/` a Android WebView `assets/web/` jsou jedna synchronizovaná verze; změny UI prováděj v `server/web/` a kopii obnov synchronizačním krokem.

## Kritický stav ověření

- Plný Android modul nebyl sestaven: prostředí nemá Android SDK, Gradle ani `adb`. Samostatný Kotlin `LocalInferenceEngine` adaptér byl kompilován, ale to nenahrazuje Gradle build celého projektu.
- `libaxiom.so` je převzata z uživatelem dodaného APK 2.1, podporuje pouze `arm64-v8a` a její C/C++ zdroje nebyly dodány. Přesná kompatibilita s konkrétním GGUF a lokální generování musí být ověřeny na Pixelu 10a.
- SHA-256 kontroluje integritu kopie, nikoli podpis modelového vydavatele. Před importem ověř hash modelu z důvěryhodného oficiálního zdroje.
- WebView a server API vyžadují integraci se skutečným tokenem, HTTPS serverem a placenými klíči.
- Místní SQLite databáze TXT/Markdown je v privátním sandboxu, nikoli samostatně šifrovaná.

## Build requirements

- Android Studio a JDK 17.
- Android SDK Platform 35 a Build Tools.
- Android Gradle Plugin 8.9.2 a Gradle 8.11.1.
- Zařízení/emulátor API 26+; lokální nativní běh zatím pouze ARM64.

Projekt nemá Gradle wrapper. Otevři `android-app/` v Android Studio, proveď Gradle Sync a build debug/release. Release potřebuje nový podpisový klíč. Nainstalování jinak podepsané aplikace přes starou `cz.axiom.app` Android odmítne; odinstalace původní aplikace smaže její privátní data a místní dokumenty.

## Fyzický test checklist

- Ověř, že aplikace otevře UI i bez lokálního modelu a lze vstoupit do Nastavení.
- Připoj HTTPS server pomocí `axm_...` tokenu; token zadej v nativním dialogu a ověř jeho uložení v Keystore.
- Zkus OpenAI, Gemini a compare s testovacími limity nákladů.
- Ověř odmítnutí cloud/memory/local-document souhlasu.
- Importuj testovací GGUF >1GB; otestuj přerušení, nedostatek místa, chybnou hlavičku, progress a SHA-256.
- Spusť krátký lokální prompt a otestuj zrušení i přechod aplikace na pozadí.
- V logcat zkontroluj chyby, ale neukládej device/API tajemství.
