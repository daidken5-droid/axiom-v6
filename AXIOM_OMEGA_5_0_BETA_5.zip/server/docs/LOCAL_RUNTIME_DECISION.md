# Rozhodnutí: lokální inference runtime — AXIOM OMEGA 5.0 Beta 4

## Co je skutečně zapojeno

Aplikace zachovává JNI adaptér `libaxiom.so` převzatý z původního APK 2.1. Jeho nativní zdroje nebyly dodány a nelze potvrdit kompatibilitu s libovolným GGUF souborem. Android importér kontroluje příponu, základní hlavičku GGUF, velikost, volné místo a SHA-256 kopie; neověřuje původ modelu ani podpis vydavatele.

`LocalInferenceEngine` odděluje orchestrace od konkrétního runtime. Jediná zapojená implementace je `LegacyLlamaCppEngine`. Tato beta tedy **neobsahuje Gemma 4 ani LiteRT-LM**.

## Doporučená další generace: Google LiteRT-LM

Aktuální oficiální dokumentace Google uvádí stabilní Kotlin API pro Android, akceleraci CPU/GPU/NPU, streamované odpovědi a nástrojové volání. Runtime uvádí podporu rodin Gemma, EmbeddingGemma, Llama, Phi a Qwen. Android integrace používá artefakt `com.google.ai.edge.litertlm:litertlm-android`; v produkčním sestavení je nutné připnout konkrétní ověřenou verzi, ne ponechat dynamické `latest.release`.

Gemma 4 E2B je model zaměřený také na mobilní a edge zařízení; oficiální dokumentace uvádí velikost vah přibližně 2,58 GB. To samo o sobě neznamená, že bude bez problémů fungovat na Pixelu 10a s 8 GB RAM: zveřejněná měření v dokumentaci nejsou měřením tohoto telefonu a skutečná paměťová režie zahrnuje runtime, KV cache, Android a další procesy.

### Implementační rozhodnutí

Po získání Android SDK/Gradle a fyzického Pixelu vytvořit `LiteRtLmEngine` jako druhý adaptér za `LocalInferenceEngine`. Inicializaci `Engine` provádět mimo UI vlákno; oficiální průvodce upozorňuje, že inicializace může trvat několik sekund. Použít asynchronní/Flow API pro streamování tokenů, explicitní `close()` při uvolnění modelu a ruční řízení tool calling. Žádný modelový tool call nesmí přímo získat neomezený přístup k OS nebo síti; každý nástroj musí mít allowlist, limity a podle rizika schválení uživatelem.

Dokumentace: 
- https://developers.google.com/edge/litert-lm/overview
- https://developers.google.com/edge/litert-lm/android
- https://developers.google.com/edge/litert-lm/models/gemma-4

## Proč runtime zatím nepřidáváme do této bety

- V pracovním prostředí není Android SDK/Gradle sestavovací prostředí ani připojený fyzický Pixel 10a.
- Je nutné potvrdit správný formát modelového balíčku a verzi LiteRT-LM artefaktu.
- Musíme změřit RAM, cold start, teplotu, latenci, rychlost generování a kompatibilitu CPU/GPU/NPU na konkrétním telefonu.
- Přidání neověřeného runtime by mohlo rozbít stávající JNI cestu, která je zatím jedinou zapojenou implementací.

## Povinný benchmark před převzetím

Na Pixelu 10a měřit cold start, peak RSS, time-to-first-token, rychlost dekódování (tok/s), spotřebu baterie, teplotu a stabilitu delšího běhu. Použít stejnou sadu alespoň 20 promptů v češtině a angličtině: shrnutí, extrakce, psaní, matematika, jednoduché programování a práce s místními dokumenty. Porovnat kvalitu s Qwen3 1.7B; model zvolit podle kombinace kvality, rychlosti a paměťové rezervy, nikoli podle počtu parametrů.

MTP (multi-token prediction) zapnout pouze po měření konkrétního backendu; dokumentace Gemma 4 uvádí potenciální zrychlení, ale profil E2B na CPU může být pro volné generování pomalejší.
