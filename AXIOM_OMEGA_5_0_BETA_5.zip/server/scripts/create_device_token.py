#!/usr/bin/env python3
"""Generate an AXIOM device bearer token. Store the plaintext only on the device."""
import hashlib
import secrets
import sys

name = sys.argv[1] if len(sys.argv) > 1 else "pixel10a"
if not name.replace("-", "").replace("_", "").isalnum():
    raise SystemExit("Device id may contain only letters, digits, '-' and '_'.")
token = "axm_" + secrets.token_urlsafe(36)
digest = hashlib.sha256(token.encode()).hexdigest()
print("DEVICE TOKEN (shown once; store in Android Keystore):")
print(token)
print("\nAdd this entry to AXIOM_DEVICE_TOKENS_JSON in .env:")
print(f'{{"{name}":"{digest}"}}')
