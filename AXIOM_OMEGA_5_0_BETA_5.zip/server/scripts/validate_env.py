#!/usr/bin/env python3
"""Validate deployment .env without printing secret values."""
from __future__ import annotations

import base64
import binascii
import json
import os
import re
import stat
import sys
from pathlib import Path


def parse_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def _valid_hostname(value: str) -> bool:
    if value.lower() == "testserver" or not value or len(value) > 253 or value.startswith(".") or value.endswith("."):
        return False
    labels = value.split(".")
    return all(
        1 <= len(label) <= 63
        and re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?", label)
        for label in labels
    )


def validate_values(values: dict[str, str], env_path: Path | None = None) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    domain = values.get("AXIOM_DOMAIN", "")
    if domain == "axiom.example.cz" or not _valid_hostname(domain):
        errors.append("AXIOM_DOMAIN must be set to a valid real DNS hostname")
    allowed_items = [item.strip() for item in values.get("AXIOM_ALLOWED_HOSTS", "").split(",") if item.strip()]
    allowed = set(allowed_items)
    if not allowed_items:
        errors.append("AXIOM_ALLOWED_HOSTS must contain explicit hostnames; wildcard is not allowed")
    elif any(item == "*" or not _valid_hostname(item) for item in allowed_items):
        errors.append("AXIOM_ALLOWED_HOSTS contains an invalid hostname or wildcard")
    if domain and domain not in allowed:
        errors.append("AXIOM_ALLOWED_HOSTS must include AXIOM_DOMAIN")

    openai_ready = bool(values.get("OPENAI_API_KEY", "").strip())
    gemini_ready = bool(values.get("GEMINI_API_KEY", "").strip())
    if not (openai_ready or gemini_ready):
        errors.append("Configure at least one provider API key (OPENAI_API_KEY or GEMINI_API_KEY)")
    elif not (openai_ready and gemini_ready):
        warnings.append("Only one provider is configured; cross-provider comparison and fallback are unavailable")

    master_key = values.get("AXIOM_MASTER_KEY", "").strip()
    try:
        decoded = base64.b64decode(master_key + "=" * (-len(master_key) % 4), altchars=b"-_", validate=True)
        if len(decoded) != 32:
            errors.append("AXIOM_MASTER_KEY must decode to exactly 32 random bytes")
    except (ValueError, binascii.Error):
        errors.append("AXIOM_MASTER_KEY must be a valid URL-safe base64 encoding of 32 random bytes")

    raw_tokens = values.get("AXIOM_DEVICE_TOKENS_JSON", "{}")
    try:
        tokens = json.loads(raw_tokens)
        if not isinstance(tokens, dict) or not tokens:
            errors.append("AXIOM_DEVICE_TOKENS_JSON must contain at least one device hash")
        else:
            for device_id, digest in tokens.items():
                if not isinstance(device_id, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", device_id):
                    errors.append("A device id contains unsupported characters")
                    break
                if not isinstance(digest, str) or not re.fullmatch(r"[a-fA-F0-9]{64}", digest):
                    errors.append("Device entries must contain SHA-256 hashes, not plaintext tokens")
                    break
    except (json.JSONDecodeError, TypeError):
        errors.append("AXIOM_DEVICE_TOKENS_JSON is not a valid JSON map")

    if env_path and env_path.exists() and os.name == "posix":
        mode = stat.S_IMODE(env_path.stat().st_mode)
        if mode & 0o077:
            errors.append("The .env file is readable by group or others; run chmod 600 .env")

    return errors, warnings


def main() -> int:
    path = Path(sys.argv[1] if len(sys.argv) > 1 else ".env")
    if not path.is_file():
        print(f"ERROR: {path} not found")
        return 2
    values = parse_env(path)
    errors, warnings = validate_values(values, path)
    for message in errors:
        print(f"ERROR: {message}")
    for message in warnings:
        print(f"WARNING: {message}")
    if not errors:
        print("OK: deployment configuration passed structural checks; secret values were not displayed")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
