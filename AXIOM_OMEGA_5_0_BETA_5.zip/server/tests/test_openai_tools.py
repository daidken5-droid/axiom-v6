import asyncio

import httpx

import app.providers as providers


def test_openai_calculator_function_call_round_trip(monkeypatch):
    requests = []
    responses = [
        {
            "id": "resp_tool",
            "output": [{
                "type": "function_call",
                "call_id": "call_1",
                "name": "axiom_calculator",
                "arguments": '{"expression":"2+3"}',
            }],
            "usage": {"input_tokens": 4, "output_tokens": 2},
        },
        {
            "id": "resp_final",
            "output_text": "Výsledek je 5.",
            "output": [{"type": "message", "content": [{"type": "output_text", "text": "Výsledek je 5."}]}],
            "usage": {"input_tokens": 6, "output_tokens": 3},
        },
    ]

    class FakeAsyncClient:
        def __init__(self, **kwargs):
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            return False

        async def post(self, url, *, headers, json):
            requests.append(json)
            return httpx.Response(
                200, json=responses[len(requests) - 1], request=httpx.Request("POST", url)
            )

    monkeypatch.setattr(providers.httpx, "AsyncClient", FakeAsyncClient)
    result = asyncio.run(providers.call_openai(
        api_key="fake", model="gpt-6.1-sol", system_prompt="System", prompt="Kolik je 2+3?",
        history=[], web_search=False, max_output_tokens=128, reasoning_effort="low", timeout=5,
        enable_calculator=True,
    ))

    assert len(requests) == 2
    assert requests[0]["store"] is False
    assert requests[0]["tools"][0]["strict"] is True
    assert requests[1]["input"][1]["type"] == "function_call"
    assert requests[1]["input"][2] == {
        "type": "function_call_output",
        "call_id": "call_1",
        "output": '{"result":5}',
    }
    assert result["text"] == "Výsledek je 5."
    assert result["usage"] == {"input_tokens": 10, "output_tokens": 5}
    assert result["tools_used"] == [{"name": "axiom_calculator", "ok": True}]


def test_openai_rejects_unapproved_function_call(monkeypatch):
    responses = [{
        "id": "resp_tool",
        "output": [{"type": "function_call", "call_id": "call_1", "name": "shell", "arguments": "{}"}],
    }]

    class FakeAsyncClient:
        def __init__(self, **kwargs):
            pass
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            return False
        async def post(self, url, *, headers, json):
            return httpx.Response(200, json=responses[0], request=httpx.Request("POST", url))

    monkeypatch.setattr(providers.httpx, "AsyncClient", FakeAsyncClient)
    try:
        asyncio.run(providers.call_openai(
            api_key="fake", model="gpt-6.1-sol", system_prompt="System", prompt="Do it",
            history=[], web_search=False, max_output_tokens=128, reasoning_effort="low", timeout=5,
            enable_calculator=False,
        ))
    except providers.ProviderError as exc:
        assert "did not authorize" in exc.safe_message
    else:
        raise AssertionError("Unapproved tool call was not rejected")
