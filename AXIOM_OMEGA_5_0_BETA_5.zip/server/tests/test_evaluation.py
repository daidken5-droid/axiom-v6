from app.evaluation import evaluate_output


def test_hades_reports_structural_checks_without_claiming_fact_check():
    result = evaluate_output("A supported answer", [{"title": "Source", "url": "https://example.com"}], True)
    assert result == {
        "structurally_valid": True,
        "source_count": 1,
        "web_search_requested": True,
        "warnings": [],
        "factual_verification": "not_performed",
    }


def test_hades_warns_when_search_has_no_safe_sources():
    result = evaluate_output("Answer", [{"title": "Unsafe", "url": "javascript:alert(1)"}], True)
    assert result["source_count"] == 0
    assert "web_search_requested_but_no_clickable_sources_returned" in result["warnings"]
