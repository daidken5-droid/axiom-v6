from types import SimpleNamespace

import pytest

from app.routing import choose_route, classify_task

CFG = SimpleNamespace(
    openai_primary_model="gpt-6.1-sol", openai_fast_model="gpt-6-luna",
    openai_reasoning_model="gpt-6-astra", openai_visual_model="gpt-6.1-terra",
    gemini_primary_model="gemini-3.8-flash", gemini_reasoning_model="gemini-4-argon",
)


def test_fast_task():
    assert classify_task("Přelož tuto větu do angličtiny.") == "fast"


def test_complex_task():
    assert classify_task("Proveď komplexní návrh architektury a threat model celé aplikace.") == "high"


def test_auto_uses_gemini_for_regular_web_lookup():
    route = choose_route(prompt="Zjisti aktuální otevírací dobu muzea.", provider_choice="auto", agent="answer",
                         use_web_search=True, openai_available=True, gemini_available=True, settings=CFG)
    assert route.provider == "gemini"
    assert route.model == "gemini-3.8-flash"


def test_auto_uses_astra_for_hard_task_even_with_web():
    route = choose_route(prompt="Proveď hloubkovou rešerši a komplexní analýzu.", provider_choice="auto", agent="research",
                         use_web_search=True, openai_available=True, gemini_available=True, settings=CFG)
    assert route.provider == "openai"
    assert route.model == "gpt-6-astra"


def test_openai_fast_model():
    route = choose_route(prompt="Shrň: Ahoj světe.", provider_choice="openai", agent="answer",
                         use_web_search=False, openai_available=True, gemini_available=True, settings=CFG)
    assert route.model == "gpt-6-luna"


def test_unconfigured_provider_fails_closed():
    with pytest.raises(RuntimeError):
        choose_route(prompt="Ahoj", provider_choice="gemini", agent="answer",
                     use_web_search=False, openai_available=True, gemini_available=False, settings=CFG)


def test_auto_uses_only_configured_provider_when_openai_missing():
    route = choose_route(prompt="Ahoj", provider_choice="auto", agent="answer",
                         use_web_search=False, openai_available=False, gemini_available=True, settings=CFG)
    assert route.provider == "gemini"


def test_auto_uses_only_configured_provider_when_gemini_missing():
    route = choose_route(prompt="Najdi aktuální informace.", provider_choice="auto", agent="answer",
                         use_web_search=True, openai_available=True, gemini_available=False, settings=CFG)
    assert route.provider == "openai"
