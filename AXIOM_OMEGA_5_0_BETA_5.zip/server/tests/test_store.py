import base64
import hashlib

import pytest

from app.store import IdempotencyConflict, PrivateStore, StoreError


def make_store(tmp_path):
    key = base64.urlsafe_b64encode(b"a" * 32).decode().rstrip("=")
    return PrivateStore(str(tmp_path / "axiom.db"), key), key


def test_memory_is_encrypted_and_device_scoped(tmp_path):
    store, _ = make_store(tmp_path)
    note = store.add_memory("pixel-a", "Projekt", "Důležitý soukromý kontext AXIOM", ["projekt"])
    assert note["title"] == "Projekt"
    results = store.search_memory("pixel-a", "soukromý kontext")
    assert results[0]["id"] == note["id"]
    assert store.search_memory("pixel-b", "soukromý kontext") == []
    raw = (tmp_path / "axiom.db").read_bytes()
    assert "Důležitý soukromý kontext".encode("utf-8") not in raw


def test_idempotency_replays_encrypted_completed_response(tmp_path):
    store, _ = make_store(tmp_path)
    body_hash = hashlib.sha256(b"request").hexdigest()
    claimed = store.begin_idempotency("pixel", "key-1", body_hash, "req-1")
    assert claimed["state"] == "pending"
    response = {"text": "OK"}
    store.complete_idempotency("pixel", "key-1", response)
    replay = store.begin_idempotency("pixel", "key-1", body_hash, "req-2")
    assert replay["cached"] == response
    with pytest.raises(IdempotencyConflict):
        store.begin_idempotency("pixel", "key-1", hashlib.sha256(b"different").hexdigest(), "req-3")


def test_pending_idempotency_blocks_double_dispatch(tmp_path):
    store, _ = make_store(tmp_path)
    body_hash = hashlib.sha256(b"request").hexdigest()
    store.begin_idempotency("pixel", "key-2", body_hash, "req-1")
    with pytest.raises(IdempotencyConflict):
        store.begin_idempotency("pixel", "key-2", body_hash, "req-2")


def test_encrypted_storage_requires_key(tmp_path):
    store = PrivateStore(str(tmp_path / "plain.db"), None)
    with pytest.raises(StoreError):
        store.add_memory("pixel", "Title", "Content", [])


def test_memory_ciphertext_is_bound_to_item_identity(tmp_path):
    store, _ = make_store(tmp_path)
    first = store.add_memory("pixel", "One", "First private note", [])
    second = store.add_memory("pixel", "Two", "Second private note", [])
    with store._connect() as con:
        row_a = con.execute("SELECT title_enc FROM memory_items WHERE id=?", (first["id"],)).fetchone()
        con.execute("UPDATE memory_items SET title_enc=? WHERE id=?", (row_a["title_enc"], second["id"]))
    from cryptography.exceptions import InvalidTag
    with pytest.raises(InvalidTag):
        store.list_memory("pixel")


def test_memory_term_index_does_not_store_plaintext_and_cascades(tmp_path):
    store, _ = make_store(tmp_path)
    note = store.add_memory("pixel-a", "Projekt AXIOM", "Důvěrný text o dlouhodobé paměti", ["bezpečnost"])
    with store._connect() as con:
        terms = con.execute("SELECT term_hash, occurrences FROM memory_terms WHERE memory_id=?", (note["id"],)).fetchall()
        assert terms
        assert all(len(row["term_hash"]) == 64 for row in terms)
        assert not any("axiom" in row["term_hash"] for row in terms)
    raw = (tmp_path / "axiom.db").read_bytes()
    assert b"dlouhodob" not in raw
    assert store.search_memory("pixel-a", "Důvěrný text")[0]["id"] == note["id"]
    assert store.delete_memory("pixel-a", note["id"]) == 1
    with store._connect() as con:
        assert con.execute("SELECT COUNT(*) FROM memory_terms WHERE memory_id=?", (note["id"],)).fetchone()[0] == 0


def test_memory_term_index_backfills_existing_rows(tmp_path):
    store, key = make_store(tmp_path)
    note = store.add_memory("pixel-a", "Starší projekt", "Migrace starých záznamů do indexu", [])
    with store._connect() as con:
        con.execute("DELETE FROM memory_terms WHERE memory_id=?", (note["id"],))
        con.execute("DELETE FROM schema_meta WHERE key='memory_term_index_v2'")
    migrated = PrivateStore(store.path, key)
    results = migrated.search_memory("pixel-a", "migrace záznamů")
    assert results and results[0]["id"] == note["id"]


def test_memory_terms_are_device_scoped(tmp_path):
    store, _ = make_store(tmp_path)
    note = store.add_memory("pixel-a", "Tajný plán", "unikátní fráze", [])
    assert store.search_memory("pixel-b", "unikátní fráze") == []
    assert store.search_memory("pixel-a", "unikátní fráze")[0]["id"] == note["id"]


def test_expired_idempotency_key_keeps_tombstone_and_never_redispatches(tmp_path):
    store, _ = make_store(tmp_path)
    store.idempotency_ttl = 1
    body_hash = hashlib.sha256(b"paid call").hexdigest()
    store.begin_idempotency("pixel", "old-key", body_hash, "req-1")
    store.complete_idempotency("pixel", "old-key", {"text": "already charged"})
    with store._connect() as con:
        con.execute("UPDATE idempotency SET created_at=? WHERE device_id=? AND idem_key=?", (0, "pixel", "old-key"))
    with pytest.raises(IdempotencyConflict, match="retained to prevent a duplicate"):
        store.begin_idempotency("pixel", "old-key", body_hash, "req-2")
    with store._connect() as con:
        row = con.execute("SELECT state,response_enc FROM idempotency WHERE device_id=? AND idem_key=?", ("pixel", "old-key")).fetchone()
        assert row["state"] == "expired"
        assert row["response_enc"] is None


def test_term_hashes_are_isolated_per_device(tmp_path):
    store, _ = make_store(tmp_path)
    store.add_memory("pixel-a", "projekt", "společný tajný výraz", [])
    store.add_memory("pixel-b", "projekt", "společný tajný výraz", [])
    with store._connect() as con:
        hashes = con.execute("SELECT DISTINCT device_id,term_hash FROM memory_terms WHERE term_hash IN (SELECT term_hash FROM memory_terms GROUP BY term_hash HAVING COUNT(DISTINCT device_id)>1)").fetchall()
    assert hashes == []


def test_memory_index_v2_rebuilds_and_removes_stale_hashes(tmp_path):
    store, key = make_store(tmp_path)
    note = store.add_memory("pixel-a", "Rebuild index", "current HMAC migration entry", [])
    with store._connect() as con:
        con.execute("DELETE FROM schema_meta WHERE key='memory_term_index_v2'")
        con.execute("INSERT INTO schema_meta(key,value) VALUES('memory_term_index_v1','done')")
        con.execute("INSERT OR REPLACE INTO memory_terms(device_id,memory_id,term_hash,occurrences) VALUES(?,?,?,?)",
                    ("pixel-a", note["id"], "f" * 64, 1))
    migrated = PrivateStore(store.path, key)
    assert migrated.search_memory("pixel-a", "current migration")[0]["id"] == note["id"]
    with migrated._connect() as con:
        hashes = [row[0] for row in con.execute("SELECT term_hash FROM memory_terms WHERE memory_id=?", (note["id"],))]
        marker = con.execute("SELECT value FROM schema_meta WHERE key='memory_term_index_v2'").fetchone()
    assert "f" * 64 not in hashes
    assert marker[0] == "done"


def test_invalid_master_key_with_ignored_characters_is_rejected(tmp_path):
    good = base64.urlsafe_b64encode(b"a" * 32).decode().rstrip("=")
    with pytest.raises(ValueError, match="URL-safe base64"):
        PrivateStore(str(tmp_path / "bad.db"), good[:10] + "!" + good[10:])


def test_stale_pending_idempotency_becomes_ambiguous_without_redispatch(tmp_path):
    store, _ = make_store(tmp_path)
    store.idempotency_ttl = 1
    body_hash = hashlib.sha256(b"in-flight paid call").hexdigest()
    store.begin_idempotency("pixel", "stale-pending", body_hash, "req-1")
    with store._connect() as con:
        con.execute("UPDATE idempotency SET created_at=? WHERE device_id=? AND idem_key=?", (0, "pixel", "stale-pending"))
    with pytest.raises(IdempotencyConflict, match="in progress or has an ambiguous"):
        store.begin_idempotency("pixel", "stale-pending", body_hash, "req-2")
    with store._connect() as con:
        row = con.execute("SELECT state,response_enc FROM idempotency WHERE device_id=? AND idem_key=?", ("pixel", "stale-pending")).fetchone()
    assert row["state"] == "ambiguous"
    assert row["response_enc"] is None
