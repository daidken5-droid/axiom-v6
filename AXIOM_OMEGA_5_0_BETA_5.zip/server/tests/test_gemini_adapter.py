from app.providers import parse_gemini_interaction


def test_parse_interactions_api_text_citations_and_usage():
    payload = {
        "id": "interaction_123",
        "status": "completed",
        "steps": [
            {"type": "google_search_call", "arguments": {"queries": ["example"]}},
            {
                "type": "model_output",
                "content": [
                    {
                        "type": "text",
                        "text": "Ověřená odpověď.",
                        "annotations": [
                            {"type": "url_citation", "url": "https://example.com/a", "title": "Zdroj A"},
                            {"type": "url_citation", "url": "javascript:alert(1)", "title": "Unsafe"},
                            {"type": "url_citation", "url": "https://example.com/a", "title": "Duplicitní"},
                        ],
                    }
                ],
            },
        ],
        "usage": {"total_input_tokens": 15, "total_output_tokens": 21},
    }
    result = parse_gemini_interaction(payload)
    assert result["text"] == "Ověřená odpověď."
    assert result["sources"] == [{"title": "Zdroj A", "url": "https://example.com/a"}]
    assert result["usage"] == {"input_tokens": 15, "output_tokens": 21}
    assert result["provider_response_id"] == "interaction_123"


def test_parse_interactions_api_supports_output_text_fallback():
    result = parse_gemini_interaction({"output_text": "Fallback text", "usage": {}})
    assert result["text"] == "Fallback text"
    assert result["sources"] == []


def test_call_gemini_uses_interactions_api_and_disables_storage(monkeypatch):
    import asyncio
    import httpx
    import app.providers as providers

    captured = {}

    class FakeAsyncClient:
        def __init__(self, **kwargs):
            captured["timeout"] = kwargs.get("timeout")

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb):
            return False

        async def post(self, url, *, headers, json):
            captured["url"] = url
            captured["headers"] = headers
            captured["payload"] = json
            return httpx.Response(
                200,
                json={
                    "id": "int_1",
                    "steps": [{"type": "model_output", "content": [{"type": "text", "text": "OK"}]}],
                    "usage": {"total_input_tokens": 3, "total_output_tokens": 1},
                },
                request=httpx.Request("POST", url),
            )

    monkeypatch.setattr(providers.httpx, "AsyncClient", FakeAsyncClient)
    result = asyncio.run(providers.call_gemini(
        api_key="not-a-real-key", model="gemini-3.8-flash", system_prompt="System", prompt="Hi",
        history=[], web_search=True, max_output_tokens=128, reasoning_effort="low", timeout=30,
    ))

    assert captured["url"] == "https://generativelanguage.googleapis.com/v1beta/interactions"
    assert captured["payload"]["model"] == "gemini-3.8-flash"
    assert captured["payload"]["store"] is False
    assert captured["payload"]["tools"] == [{"type": "google_search"}]
    assert result["text"] == "OK"
    assert result["provider_response_id"] == "int_1"


def test_call_gemini_round_trips_function_call_statelessly(monkeypatch):
    import asyncio
    import httpx
    import app.providers as providers

    requests = []
    responses = [
        {
            "id": "int_tool",
            "steps": [{"type": "function_call", "id": "call_1", "name": "axiom_calculator", "arguments": {"expression": "2+3"}}],
            "usage": {"total_input_tokens": 4, "total_output_tokens": 2},
        },
        {
            "id": "int_final",
            "steps": [{"type": "model_output", "content": [{"type": "text", "text": "Výsledek je 5."}]}],
            "usage": {"total_input_tokens": 6, "total_output_tokens": 3},
        },
    ]

    class FakeAsyncClient:
        def __init__(self, **kwargs): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *args): return False
        async def post(self, url, *, headers, json):
            requests.append(json)
            return httpx.Response(200, json=responses[len(requests) - 1], request=httpx.Request("POST", url))

    monkeypatch.setattr(providers.httpx, "AsyncClient", FakeAsyncClient)
    result = asyncio.run(providers.call_gemini(
        api_key="fake", model="gemini-3.8-flash", system_prompt="System", prompt="Kolik je 2+3?",
        history=[], web_search=False, max_output_tokens=128, reasoning_effort="low", timeout=5,
        enable_calculator=True,
    ))
    assert len(requests) == 2
    assert requests[0]["store"] is False and requests[1]["store"] is False
    assert requests[1]["input"][1] == responses[0]["steps"][0]
    assert requests[1]["input"][2]["type"] == "function_result"
    assert requests[1]["input"][2]["call_id"] == "call_1"
    assert '"result":5' in requests[1]["input"][2]["result"][0]["text"]
    assert result["text"] == "Výsledek je 5."
    assert result["usage"] == {"input_tokens": 10, "output_tokens": 5}
    assert result["tools_used"] == [{"name": "axiom_calculator", "ok": True}]
