import pytest
from app.tools import safe_calculate


def test_safe_calculator():
    assert safe_calculate("(12 + 8) * 3 / 2") == 30


@pytest.mark.parametrize("expr", ["__import__('os').system('id')", "open('/etc/passwd')", "2 ** 99", "1 / 0", "x + 1"])
def test_calculator_rejects_unsafe_expressions(expr):
    with pytest.raises(ValueError):
        safe_calculate(expr)


@pytest.mark.parametrize("expr", ["9" * 100, "1e999", "(10 ** 8) ** 2"])
def test_calculator_rejects_extreme_numeric_values(expr):
    with pytest.raises(ValueError):
        safe_calculate(expr)
