from dataclasses import replace

from fastapi.testclient import TestClient

import app.main as main
from app.security import issue_device_token


def test_health_has_no_secret_metadata():
    client = TestClient(main.app, base_url="http://localhost")
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
    assert "providers" not in response.json()


def test_config_requires_device_token(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(main.settings, device_tokens={"pixel10a": digest}))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.get("/v1/config", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.json()["device_id"] == "pixel10a"


def test_cloud_requires_explicit_consent(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(main.settings, device_tokens={"pixel10a": digest}))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={"prompt": "Ahoj", "provider": "openai", "cloud_consent": False},
    )
    assert response.status_code == 403


def test_local_jobs_are_not_forwarded_to_cloud(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(main.settings, device_tokens={"pixel10a": digest}))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={"prompt": "Ahoj", "provider": "local", "cloud_consent": True},
    )
    assert response.status_code == 409


def test_combined_history_context_limit_is_enforced(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(
        main.settings, device_tokens={"pixel10a": digest}, max_prompt_chars=20000, max_context_chars=4000
    ))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "prompt": "Ahoj",
            "history": [{"role": "user", "content": "x" * 3998}],
            "provider": "openai",
            "cloud_consent": True,
        },
    )
    assert response.status_code == 413


def test_local_document_context_requires_separate_consent(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(main.settings, device_tokens={"pixel10a": digest}))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "prompt": "Shrň soubor.",
            "provider": "openai",
            "cloud_consent": True,
            "local_context": [{"title": "Poznámka", "content": "Soukromý text."}],
            "local_context_consent": False,
        },
    )
    assert response.status_code == 403
    assert "local document excerpts" in response.json()["detail"]


def test_local_context_consent_also_requires_cloud_consent(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(main.settings, device_tokens={"pixel10a": digest}))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "prompt": "Shrň soubor.",
            "provider": "openai",
            "cloud_consent": False,
            "local_context": [{"title": "Poznámka", "content": "Soukromý text."}],
            "local_context_consent": True,
        },
    )
    assert response.status_code == 403
    assert "Cloud processing" in response.json()["detail"]


def test_local_context_is_included_in_total_context_limit(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(
        main.settings, device_tokens={"pixel10a": digest}, max_prompt_chars=20000, max_context_chars=4000
    ))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={
            "prompt": "Shrň soubor.",
            "provider": "openai",
            "cloud_consent": True,
            "local_context_consent": True,
            "local_context": [{"title": "Poznámka", "content": "x" * 4000}],
        },
    )
    assert response.status_code == 413


def test_cloud_request_requires_idempotency_key(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(
        main.settings, device_tokens={"pixel10a": digest}, openai_api_key="test-key"
    ))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}"},
        json={"prompt": "Napiš krátký text.", "provider": "openai", "cloud_consent": True},
    )
    assert response.status_code == 400
    assert "Idempotency-Key" in response.json()["detail"]


def test_paid_cloud_requests_require_encrypted_idempotency_store(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(
        main.settings, device_tokens={"pixel10a": digest}, openai_api_key="test-key"
    ))
    monkeypatch.setattr(main.store, "key", None)
    client = TestClient(main.app, base_url="http://localhost")
    response = client.post(
        "/v1/chat",
        headers={"Authorization": f"Bearer {token}", "Idempotency-Key": "request-123"},
        json={"prompt": "Napiš krátký text.", "provider": "openai", "cloud_consent": True},
    )
    assert response.status_code == 503
    assert "AXIOM_MASTER_KEY" in response.json()["detail"]


def test_private_api_responses_are_not_cacheable(monkeypatch):
    token, digest = issue_device_token()
    monkeypatch.setattr(main, "settings", replace(main.settings, device_tokens={"pixel10a": digest}))
    client = TestClient(main.app, base_url="http://localhost")
    response = client.get("/v1/config", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert response.headers["cache-control"] == "no-store, max-age=0"
    assert response.headers["pragma"] == "no-cache"
