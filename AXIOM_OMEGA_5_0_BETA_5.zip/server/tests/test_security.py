import hashlib

import pytest
from fastapi import HTTPException

from app.security import authenticate_token, issue_device_token


def test_token_generation_and_validation():
    token, digest = issue_device_token()
    assert hashlib.sha256(token.encode()).hexdigest() == digest
    device = authenticate_token(token, {"pixel10a": digest})
    assert device.device_id == "pixel10a"


def test_bad_token_rejected():
    with pytest.raises(HTTPException) as exc:
        authenticate_token("wrong", {"pixel10a": "0" * 64})
    assert exc.value.status_code == 401
