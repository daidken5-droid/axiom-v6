import base64
import json

import pytest

from scripts.validate_env import validate_values


def good_values():
    return {
        "AXIOM_DOMAIN": "axiom.example.net",
        "AXIOM_ALLOWED_HOSTS": "axiom.example.net,localhost",
        "OPENAI_API_KEY": "test-key",
        "GEMINI_API_KEY": "test-key",
        "AXIOM_MASTER_KEY": base64.urlsafe_b64encode(b"x" * 32).decode().rstrip("="),
        "AXIOM_DEVICE_TOKENS_JSON": json.dumps({"pixel10a": "a" * 64}),
    }


def test_valid_deploy_config_has_no_errors():
    errors, warnings = validate_values(good_values())
    assert errors == []
    assert warnings == []


def test_plaintext_device_token_rejected():
    values = good_values()
    values["AXIOM_DEVICE_TOKENS_JSON"] = json.dumps({"pixel10a": "axm_this_is_not_a_hash"})
    errors, _ = validate_values(values)
    assert any("SHA-256 hashes" in item for item in errors)


def test_bad_domain_and_master_key_rejected():
    values = good_values()
    values["AXIOM_DOMAIN"] = "https://not-a-host"
    values["AXIOM_MASTER_KEY"] = "not-a-key"
    errors, _ = validate_values(values)
    assert any("valid real DNS hostname" in item for item in errors)
    assert any("base64 encoding" in item for item in errors)


def test_runtime_config_rejects_wildcard_allowed_host(monkeypatch):
    from app.config import load_settings
    monkeypatch.setenv("AXIOM_ALLOWED_HOSTS", "*,axiom.example.net")
    with pytest.raises(ValueError, match="invalid host or wildcard"):
        load_settings()


def test_runtime_config_rejects_plaintext_device_token(monkeypatch):
    from app.config import load_settings
    monkeypatch.setenv("AXIOM_DEVICE_TOKENS_JSON", '{"pixel10a":"axm_plaintext"}')
    with pytest.raises(ValueError, match="SHA-256 hashes"):
        load_settings()


def test_deployment_validation_rejects_wildcard_even_with_valid_domain():
    values = {
        "AXIOM_DOMAIN": "axiom.example.net",
        "AXIOM_ALLOWED_HOSTS": "axiom.example.net,*",
        "OPENAI_API_KEY": "test-key",
        "AXIOM_MASTER_KEY": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
        "AXIOM_DEVICE_TOKENS_JSON": '{"pixel10a":"' + "a" * 64 + '"}',
    }
    errors, _ = validate_values(values)
    assert any("wildcard" in error for error in errors)


def test_runtime_default_hosts_exclude_testserver(monkeypatch):
    from app.config import load_settings
    monkeypatch.delenv("AXIOM_ALLOWED_HOSTS", raising=False)
    settings = load_settings()
    assert "testserver" not in settings.allowed_hosts
    assert set(settings.allowed_hosts) == {"localhost", "127.0.0.1"}


def test_runtime_config_rejects_testserver_hostname(monkeypatch):
    from app.config import load_settings
    monkeypatch.setenv("AXIOM_ALLOWED_HOSTS", "axiom.example.net,testserver")
    with pytest.raises(ValueError, match="invalid host or wildcard"):
        load_settings()


def test_deployment_validation_rejects_testserver_hostname():
    values = good_values()
    values["AXIOM_ALLOWED_HOSTS"] = "axiom.example.net,testserver"
    errors, _ = validate_values(values)
    assert any("invalid hostname or wildcard" in error for error in errors)
