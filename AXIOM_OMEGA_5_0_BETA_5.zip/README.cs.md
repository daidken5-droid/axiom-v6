# AXIOM OMEGA 5.0.0 Beta 5

**Adaptivní hybridní asistent: Android klient + soukromý server + lokální inference.**

Tento archiv je zdrojová vývojová beta. **Není to hotové APK, nasazený VPS ani ověřená produkční služba.** Výsledky automatických testů a statických kontrol jsou uvedené v `STATUS_CZ.md`.

## Co obsahuje

- `android-app/` — Android Studio projekt, WebView UI, bezpečný nativní most, Keystore, GGUF importer, místní SQLite FTS4 knihovna a adaptér lokální inference.
- `server/` — FastAPI backend, OpenAI Responses API, Gemini Interactions API, adaptivní routing, bezpečnostní limity, šifrovaná paměť, kalkulačka, PWA a Docker/Caddy deployment.
- `assets/` — monochromatický symbol AXIOM.
- `STATUS_CZ.md` — stav a limity ověření.
- `CHANGELOG_5_0_0_BETA_5.md` — změny této verze.
- `BUILD_RESULT_CZ.md` — přesný stav požadavku na APK.
- `android-app/BUILD_APK_CZ.md` — návod k vytvoření instalačního APK přes GitHub Actions nebo Android Studio.
- `.github/workflows/android-apk.yml` — automatická kompilace, podpis a kontrola testovacího APK.
- `server/docs/` — architektura, bezpečnostní model, instalace, integrační kontrakt a produkční checklist.

## Architektura

```text
Google Pixel 10a / Android
  ├─ WebView UI (assets sdílené s PWA)
  ├─ Android Keystore: device token
  ├─ LocalInferenceEngine
  │    └─ LegacyLlamaCppEngine -> původní arm64-v8a libaxiom.so
  ├─ GGUF streaming importer (1 MiB bloky, SHA-256, header validation)
  ├─ Local SQLite FTS4 TXT/Markdown library
  └─ HTTPS-only API client
       │
       ▼
Caddy TLS / security headers
       │
       ▼
FastAPI AXIOM Core
  ├─ RANDY: transparentní deterministický routing
  ├─ OpenAI Responses API + web_search
  ├─ Gemini Interactions API + google_search
  ├─ explicit consent + idempotency + usage metadata
  ├─ encrypted AES-GCM memory + per-device HMAC lexical index
  ├─ bounded arithmetic tool (max 2 calls/provider/request)
  └─ HADES: strukturální kontrola, nikoli fact-check
```

## Co funguje ve zdrojích

- OpenAI Responses API a Gemini Interactions API; model IDs jsou nastavitelné v `.env`.
- OpenAI/Gemini web search přes jejich nativní nástroje.
- RANDY vybírá rychlý, standardní nebo reasoning model pomocí vysvětlitelné heuristiky. Není to natrénovaný ani benchmarkem optimální router.
- `answer`, `research`, `writer` a `audit` jsou zatím instrukční profily jednoho omezeného workflow, nikoli plně autonomní agenti.
- Cloudové zpracování vyžaduje explicitní souhlas. Porovnání obou providerů, odeslání místních dokumentů a připojení serverové paměti mají samostatné potvrzení.
- Cloud požadavky potřebují `Idempotency-Key`. Dokončená odpověď je po omezenou dobu uložena šifrovaně kvůli bezpečnému opakovanému doručení. Po TTL zůstane tombstone; starší `pending` se změní na `ambiguous`, aby se placený požadavek znovu nespustil.
- Serverové poznámky jsou AES-GCM šifrované s AAD navázanými na zařízení a položku. Lexikální index používá per-device HMAC v2; neukládá prostá slova, ale odhaluje opakování stejných termínů v rámci jednoho zařízení.
- Provozní běhy uchovávají metadata, ne prompt ani odpověď.
- Kalkulačka používá AST allowlist, rozsahové limity a nemá filesystem, síť ani shell.
- Android ukládá device token šifrovaně přes Android Keystore. Server uchovává pouze SHA-256 hash tokenu.
- GGUF se importuje proudově po blocích mimo UI vlákno; kontroluje se SHA-256 a 24bajtová hlavička GGUF verze 2/3.
- Místní knihovna TXT/Markdown je SQLite FTS4; odeslání výňatků do cloudu vyžaduje samostatné potvrzení.

## Bezpečnostní zásady

- OpenAI/Gemini API klíče patří pouze do serverového secret store nebo `.env` s oprávněními `600`. Nikdy nepatří do APK, PWA ani chatu.
- Používej HTTPS; Android odmítá cleartext HTTP a přesměrování.
- Nezapínej request-body logging ani veřejnou dokumentaci API.
- Nepovoluj agentům obecný shell, souborový systém nebo libovolné HTTP požadavky. Nové nástroje musí mít allowlist, limity a lidské potvrzení pro vedlejší efekty.
- Webové výsledky, paměť a importované dokumenty jsou nedůvěryhodná data, nikoli instrukce.
- Viz `server/docs/SECURITY_MODEL.md`.

## Co není hotové nebo ověřené

- APK nebylo sestaveno ani podepsáno. Pracovní prostředí nemá Android SDK ani Gradle toolchain a projekt nemá Gradle wrapper.
- Nebyl proveden test na fyzickém Pixelu 10a.
- VPS, doména a TLS nejsou nasazeny.
- Živé placené API volání OpenAI/Gemini nebylo provedeno.
- Původní `libaxiom.so` byla převzata z APK 2.1; její C/C++ zdroje nebyly dodány. Lokální inference s konkrétním GGUF není ověřena.
- `LocalInferenceEngine` je nyní rozhraní s jediným legacy JNI adaptérem. Gemma 4 E2B/LiteRT-LM není součástí runtime; je doporučeným dalším kandidátem po benchmarku na Pixelu.
- SHA-256 GGUF ověřuje integritu kopie, ne původ modelu ani podpis vydavatele.
- Místní SQLite znalostní databáze je v privátním aplikačním sandboxu, ale není samostatně šifrovaná.
- HADES ověřuje pouze strukturu a bezpečnost URL. Neověřuje pravdivost, důvěryhodnost zdrojů ani správnost citací.
- Streaming odpovědí, upload obrázků, sémantické/vektorové vyhledávání a obecné více-krokové autonomní agenty nejsou implementované.
- Rate limiter je jednoprocesový; horizontální škálování vyžaduje Redis/distribuovaný limiter.

## Server — lokální test

```bash
cd server
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
pytest -q
python -m compileall -q app scripts
```

## Nasazení serveru

1. Připrav VPS s Ubuntu 24.04 LTS nebo Debian 12, DNS doménu a veřejné porty 80/443.
2. Nahraj složku `server/` do `/opt/axiom-omega`.
3. Zkopíruj `.env.example` na `.env` a nastav `chmod 600 .env`.
4. Na VPS vygeneruj master key (`python3 scripts/generate_master_key.py`) a device token (`python3 scripts/create_device_token.py pixel10a`). Ulož pouze hash tokenu do `.env`; plaintext přenes bezpečně do telefonu.
5. Nastav provider API klíče pouze na serveru.
6. Spusť `python3 scripts/validate_env.py .env`, `docker compose config` a `docker compose up -d --build`.
7. Ověř `/health` a `/ready` přes HTTPS.

Podrobnosti: `server/docs/DEPLOY_CZ.md` a `server/docs/PRODUCTION_CHECKLIST_CZ.md`.

## Android build

Nejjednodušší postup je nahrát projekt do soukromého GitHub repozitáře a spustit **Actions → Build AXIOM OMEGA Android APK → Run workflow**. Workflow sestaví a ověří testovací debug APK a zveřejní ho jako artifact. Přesný postup je v `android-app/BUILD_APK_CZ.md`.

Lokální varianta: otevři `android-app/` v Android Studio s JDK 17, Android SDK Platform 35, Android Gradle Pluginem 8.9.2 a Gradle 8.11.1. Projekt nemá Gradle wrapper. Release APK vyžaduje vlastní dlouhodobý podpisový klíč. Debug build má aplikační ID `cz.axiom.app.dev` a může být nainstalován vedle původního AXIOMu.

## Licence a třetí strany

Původní `libaxiom.so` je převzatá z dodaného APK uživatele; její licence/původní zdrojový kód nebyly v této práci nezávisle ověřeny. Před veřejnou redistribucí je nutné ověřit práva k této knihovně, ikonám, modelům a všem závislostem. Modely mají vlastní licenční podmínky; ověř je pro konkrétní distribuci.
