# AXIOM OMEGA 5.0.0 Beta 5

## Změny

- Přidán GitHub Actions workflow pro vytvoření a ověření instalačního Android debug APK.
- Workflow připíná JDK 17, Android SDK Platform 35, Build Tools 35.0.0, AGP 8.9.2 a Gradle 8.11.1.
- Před Android kompilací spouští 60 serverových regresních testů.
- Po sestavení ověřuje APK podpis, aplikační ID a SHA-256.
- Zvýšen `versionCode` na 50005 a `versionName` na `5.0.0-beta.5`.
- Sjednocen UI build label a PWA cache namespace na Beta 5.
- Doplněn český návod k vytvoření APK přes GitHub Actions a Android Studio.

## Důležité omezení

APK nebylo možné sestavit v tomto pracovním prostředí: chybí Gradle a Android SDK a síťové stahování build nástrojů není dostupné. Připravené workflow je nutné spustit po nahrání zdrojového projektu do GitHub repozitáře. Výsledné debug APK je testovací build s aplikačním ID `cz.axiom.app.dev`, není to produkční release podpis.
