# AXIOM OMEGA 5.0.0 Beta 1

- Nový Android Studio projekt a PWA/WebView klient.
- Soukromý FastAPI backend s OpenAI Responses API a Gemini Interactions API.
- Adaptivní počáteční routing RANDY, explicitní cloudová oprávnění a metadata-only běhové záznamy.
- Šifrovaná serverová paměť AES-GCM a idempotency cache.
- Nativní uložení device tokenu v Android Keystore.
- Import GGUF proudovým kopírováním, kontrola hlavičky a SHA-256.
- Místní TXT/Markdown knihovna přes SQLite FTS4 s odděleným potvrzením pro sdílení úryvků do cloudu.
- Strukturální HADES kontroly a bezpečné výpočty.

Omezení této bety jsou uvedena v `STATUS_CZ.md`.
