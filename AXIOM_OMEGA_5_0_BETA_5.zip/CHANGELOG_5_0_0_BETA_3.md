# AXIOM OMEGA 5.0.0 Beta 3

Datum: 1. listopadu 2026

## Změny oproti Beta 2

- Opravená migrace HMAC indexu paměti: používá per-device odvození klíče v2, atomické přebudování a odstranění zastaralých hashů.
- Přísné dekódování `AXIOM_MASTER_KEY`; neplatné znaky se už tiše neignorují.
- Runtime validace device ID, SHA-256 hashů a seznamu povolených hostů; wildcard hosty jsou zakázané. Výchozí runtime hosty jsou pouze localhost a 127.0.0.1; testovací hostname není povolen automaticky.
- Kontrola readiness nově ověřuje také existenci alespoň jednoho device tokenu.
- Zastaralé `pending` idempotency záznamy se po TTL mění na `ambiguous`, nikdy se znovu nespustí jako placené volání.
- Index pro čištění idempotency cache a SQLite `secure_delete`.
- Bezpečnější numerické limity kalkulačky a nové testy extrémních vstupů.
- Jednotná kopie klientského JavaScriptu v PWA a Android WebView; opravena starší Android UI větev, která mohla nechat odesílací formulář zamknutý po zrušení souhlasu a neměla správné bezpečné retry prvky.
- Oddělené rozhraní `LocalInferenceEngine`; současná implementace zůstává historický JNI/llama.cpp adaptér, což připravuje čistou cestu pro budoucí LiteRT-LM adaptér.
- Zpřesněna hláška minimální velikosti GGUF souboru.
- Aktualizovány verze, dokumentace, security model a produkční kontrolní seznam.
- Připnuty přímé verze serverových runtime závislostí podle testovaného prostředí.
- Produkční `.env` validace odmítá wildcard hosty i při současně uvedené správné doméně.
- V produkčním Uvicorn procesu vypnut access log kvůli možnému úniku vyhledávacích dotazů v URL; privátní API odpovědi mají no-store hlavičky.

## Ověření

- Serverové testy: 55 passed.
- Python compileall: prošel.
- Node.js syntax check klienta: prošel.
- Android XML parse: prošel.
- Web asset parity (PWA/Android): prošla.
- Kotlin samostatného runtime adaptéru a GGUF importéru: viz status; plná Android Gradle kompilace zde není dostupná.

## Co zůstává neověřeno

- Plná kompilace APK a test UI na fyzickém Pixelu 10a.
- Živá volání OpenAI/Gemini, server na VPS, TLS a provozní monitoring.
- Lokální inference přes převzatou `libaxiom.so` a kompatibilita s konkrétním GGUF modelem.
- Gemma 4 přes LiteRT-LM není součástí běhové implementace této bety.

Beta 3 je zdrojová vývojová sestava, nikoli podepsané APK nebo produkční nasazení.
