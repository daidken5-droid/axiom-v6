# Výsledek požadavku na instalační APK

**Instalační APK v tomto prostředí nebylo vytvořeno.** Ověřené důvody:

- `gradle --offline -p android-app assembleDebug` končí kódem 127: `gradle: command not found`.
- `ANDROID_HOME` a `ANDROID_SDK_ROOT` nejsou nastavené.
- V prostředí nebyly nalezeny `android.jar`, `aapt2`, `d8` ani `apksigner`.
- Přístup k oficiálnímu Gradle distribution hostu a Android SDK hostu selhal při DNS rozlišení; build nástroje nelze stáhnout v tomto prostředí.

Nepoužil jsem starý DEX z AXIOM 2.1 jako náhradu za nový klient: jeho nativní most má jiné API než Beta 5 (`Axiom` vs. `AxiomNative`) a záměna webového UI by mohla vytvořit APK, které se spustí, ale nové funkce nebudou fungovat.

## Připravená cesta k APK

Projekt obsahuje workflow `.github/workflows/android-apk.yml`. Po nahrání celého projektu do soukromého GitHub repozitáře lze v **Actions → Build AXIOM OMEGA Android APK → Run workflow** sestavit a ověřit debug APK. Workflow publikuje artifact `AXIOM-OMEGA-5.0-Beta-5-debug-APK`.

Debug APK používá ID `cz.axiom.app.dev`; je to testovací build podepsaný debug klíčem. Může být nainstalován vedle původního `cz.axiom.app`. Nejde o produkční release podpis a jednotlivé CI běhy nemusí mít stejný debug podpis.
