package cz.axiom.omega

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Minimal Android API client. Use HTTPS outside local development. */
class AxiomApiClient(baseUrl: String, private val deviceToken: String) {
    private val root = baseUrl.trimEnd('/')

    suspend fun config(): JSONObject = request("GET", "/v1/config")

    suspend fun chat(payload: JSONObject, idempotencyKey: String = UUID.randomUUID().toString()): JSONObject =
        request("POST", "/v1/chat", payload, idempotencyKey)

    private suspend fun request(
        method: String,
        path: String,
        body: JSONObject? = null,
        idempotencyKey: String? = null
    ): JSONObject = withContext(Dispatchers.IO) {
        require(root.startsWith("https://") || root.startsWith("http://10.0.2.2")) {
            "AXIOM requires HTTPS outside the Android emulator"
        }
        val connection = (URL(root + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 12_000
            readTimeout = 130_000
            setRequestProperty("Authorization", "Bearer $deviceToken")
            setRequestProperty("Accept", "application/json")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                idempotencyKey?.let { setRequestProperty("Idempotency-Key", it) }
            }
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val parsed = if (responseText.isNotBlank()) JSONObject(responseText) else JSONObject()
            if (code !in 200..299) throw IllegalStateException(parsed.optString("detail", "AXIOM server HTTP $code"))
            parsed
        } finally {
            connection.disconnect()
        }
    }
}
