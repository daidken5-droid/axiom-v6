package cz.axiom.omega

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Store the device bearer token encrypted with an Android Keystore AES-GCM key. */
class DeviceTokenVault(context: Context) {
    private val prefs = context.getSharedPreferences("axiom_secure", Context.MODE_PRIVATE)
    private val alias = "axiom.device.token.aes"
    private val storeType = "AndroidKeyStore"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(storeType).apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, storeType)
        generator.init(KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    fun save(token: String) {
        require(token.startsWith("axm_") && token.length >= 32) { "Invalid AXIOM device token" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + encrypted
        prefs.edit().putString("device_token", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun read(): String? {
        val packed = prefs.getString("device_token", null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return null
        if (packed.size < 13) return null
        val iv = packed.copyOfRange(0, 12)
        val cipherText = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
        return cipher.doFinal(cipherText).toString(Charsets.UTF_8)
    }

    fun clear() { prefs.edit().remove("device_token").apply() }
}
