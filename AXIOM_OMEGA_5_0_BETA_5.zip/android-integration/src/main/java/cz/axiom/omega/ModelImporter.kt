package cz.axiom.omega

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

/**
 * Large GGUF import for Android Storage Access Framework.
 * Copies in bounded chunks, checks available storage, validates GGUF magic,
 * hashes the complete file and only replaces the previous model after success.
 */
object ModelImporter {
    data class Result(val file: File, val bytes: Long, val sha256: String)

    private const val BUFFER_SIZE = 4 * 1024 * 1024
    private const val MIN_FREE_AFTER_IMPORT = 256L * 1024 * 1024
    private const val MAX_MODEL_BYTES = 8L * 1024 * 1024 * 1024

    suspend fun importGguf(
        context: Context,
        source: Uri,
        onProgress: (copied: Long, total: Long?) -> Unit = { _, _ -> }
    ): Result = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val total = resolver.query(source, arrayOf(OpenableColumns.SIZE), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getLong(0).takeIf { it > 0 } else null }
        require(total == null || total <= MAX_MODEL_BYTES) { "Model exceeds the 8 GiB import limit" }

        val modelDir = File(context.filesDir, "models").apply { mkdirs() }
        val stat = StatFs(modelDir.absolutePath)
        val required = (total ?: (2L * 1024 * 1024 * 1024)) + MIN_FREE_AFTER_IMPORT
        require(stat.availableBytes >= required) { "Not enough free internal storage for this model" }

        val temporary = File(modelDir, "brain.gguf.partial")
        val destination = File(modelDir, "brain.gguf")
        val backup = File(modelDir, "brain.gguf.previous")
        temporary.delete()

        val digest = MessageDigest.getInstance("SHA-256")
        var copied = 0L
        var firstFour = ByteArray(0)
        try {
            val input = resolver.openInputStream(source) ?: error("Android could not open the selected file")
            input.use { inputStream ->
                FileOutputStream(temporary).use { output ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    while (true) {
                        val read = inputStream.read(buffer)
                        if (read < 0) break
                        if (read == 0) continue
                        if (copied == 0L) firstFour = buffer.copyOfRange(0, minOf(4, read))
                        copied += read
                        require(copied <= MAX_MODEL_BYTES) { "Model exceeds the 8 GiB import limit" }
                        digest.update(buffer, 0, read)
                        output.write(buffer, 0, read)
                        onProgress(copied, total)
                    }
                    output.fd.sync()
                }
            }
            require(copied >= 4L && firstFour.contentEquals(byteArrayOf(0x47, 0x47, 0x55, 0x46))) {
                "The selected file is not a GGUF model (missing GGUF header)"
            }
            if (destination.exists()) {
                backup.delete()
                check(destination.renameTo(backup)) { "Could not preserve the previous model" }
            }
            if (!temporary.renameTo(destination)) {
                if (backup.exists()) backup.renameTo(destination)
                error("Could not move the imported model into place")
            }
            backup.delete()
            Result(destination, copied, digest.digest().joinToString("") { "%02x".format(it) })
        } catch (error: Throwable) {
            temporary.delete()
            if (!destination.exists() && backup.exists()) backup.renameTo(destination)
            throw error
        }
    }
}
