// Historical integration note retained for reference only.
// The Android application module now wraps the JNI ABI recovered from AXIOM Hybrid 2.1
// in app/src/main/java/cz/axiom/app/Offline.java. Do not use this interface as a
// substitute for device validation: the copied libaxiom.so must be tested on the target
// Pixel 10a with the exact GGUF model before declaring offline inference production-ready.
