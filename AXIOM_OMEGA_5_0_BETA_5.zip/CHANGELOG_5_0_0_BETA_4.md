# AXIOM OMEGA 5.0.0 Beta 4

Datum: 1. listopadu 2026

## Polish a změny oproti Beta 3

- Zpřísněn výchozí seznam Trusted Hosts: `testserver` už není povolen v běžném runtime. Výchozí lokální hosty jsou pouze `localhost` a `127.0.0.1`.
- Deployment validátor `.env` nyní odmítá wildcard hosty, neplatné hostname a rezervovaný testovací `testserver` ještě před sestavením kontejneru.
- Testovací klienti používají explicitní `localhost`, aby testovací hostname nebyl potřeba v runtime konfiguraci.
- Aktualizován plán lokální inference podle aktuální dokumentace LiteRT-LM: stabilní Kotlin API, CPU/GPU/NPU, streamování, inicializace na pozadí a explicitní uvolnění runtime.
- Dokumentace výslovně odděluje Gemma 4 E2B jako kandidáta od skutečně zapojeného legacy llama.cpp adaptéru. Výkon na Pixelu 10a není odhadován z benchmarků jiných telefonů.
- Zjednodušena a sjednocena verze build labelů, PWA cache a Android `versionCode`.

## Ověření této sestavy

- Serverové testy: **60/60 passed**.
- `python -m compileall -q app scripts`: passed.
- `node --check web/app.js`: passed.
- Android XML parse: passed.
- PWA/WebView asset parity: passed.
- Kotlin runtime abstraction compile: passed independently with `javac` + `kotlinc`; full Android Gradle build not available.
- Android SDK, Gradle, Docker, adb and physical Pixel test are unavailable in the build environment.

## Zbývající omezení

Beta 4 je zdrojová vývojová sestava. Není podepsaným APK, nemá živě nasazený VPS a neověřuje placená API volání ani lokální inferenci na Pixelu 10a. Streamování cloudových odpovědí, vektorové vyhledávání, Gemma/LiteRT-LM runtime a obecný autonomní orchestrátor nejsou hotové.
